# 冻结范围与复核门

本轮范围已冻结为：20个旧物理案例的完整可用工件接入、5个公开来源契约、2个公开物理例的10次真实无头计算、4项已复现入口缺陷的修复、可离线重放的独立审查包。原fea-readiness外审包保持字节不变，不调整M33/M37冻结参考和验收容差。

| 门 | 可执行证据 | 当前源目录结果 |
|---|---|---|
| C1 案例集合完整 | CATALOG与legacy/index、public index精确集合 | 25=20+5，变体不计新例 |
| C2 来源与解析 | research/build_catalog.py --check | 5例契约一致；Hertz4项标量检查通过 |
| C3 原生前处理/结果/运行入口 | unittest discover -s tests -v | 12项通过，含4种已复现漏检的负例 |
| C4 新实际求解证据 | caselab.studies.replay_public | 10job的case/deck/raw hash、STA、U/RF覆盖及当前预检通过；原厚度梁数值FAIL保留 |
| C5 预检拒绝与网格趋势 | 同上 | 球粗网格求解前拒绝；球输出末位振荡，不生成正阶认证 |
| C6 旧案例全覆盖 | legacy/verify.py | 20case/124entry/769去重工件；14个L2各三级与原/修正16相位齐全 |
| C7 包结构/身份 | tools/replay.py + MANIFEST.json | 分发包必须精确文件集合与全部SHA通过，缺项不可忽略 |
| C8 便携重放 | 干净中文空格目录解压后运行tools/replay.py | 交付时在包外DELIVERY-VALIDATION.json记录；不回写冻结证据 |

C7/C8是实际交付工件门，不由本文件的叙述自行判定。测试输出和外部审查输出统一写包外。整体工程认可保持false，当前新案例的RF平衡/应力资格仍未闭环，三个新来源没有冒充已求解。

后续改进优先级见docs/ARCHITECTURE.md，明确接口和适用域后再扩展；本轮不靠增加探索试算来掩盖未关闭项。
