"""Bounded, evidence-backed benchmark harness. Does not certify gear designs."""
__version__='0.1.0'
