import hashlib
import json
import math
from pathlib import Path

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'),parse_constant=lambda s:(_ for _ in ()).throw(ValueError(s)))
def write(path,data):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(data):return hashlib.sha256(json.dumps(data,sort_keys=True,allow_nan=False).encode()).hexdigest()
def number(x,name,positive=False):
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or positive and x<=0:raise ValueError(name)
    return float(x)
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def sum_loads(nodes,loads):
    f=[0.,0.,0.];m=[0.,0.,0.]
    for n,d,v in loads:
        q=[0.,0.,0.];q[d-1]=v;mm=cross(nodes[n],q)
        for j in range(3):f[j]+=q[j];m[j]+=mm[j]
    return {'force':f,'moment':m,'origin':[0,0,0]}

def validate_case(case):
    for key in ['id','title','model','units','geometry','material','loading','reference','source','mesh_levels']:
        if key not in case:raise ValueError('missing '+key)
    if not case['id'] or case['units']!='N-mm-MPa':raise ValueError('identity/units')
    if case['model'] not in ['cantilever_body_force','hollow_sphere_external_pressure','hertz_spheres']:
        raise ValueError('unsupported model')
    mat=case['material'];number(mat['E_MPa'],'E',True);nu=number(mat['nu'],'nu')
    if not -1<nu<.5:raise ValueError('nu')
    src=case['source']
    if not src.get('url') or not src.get('locator') or not src.get('reference_type'):raise ValueError('source/QOI locator required')
    ref=case['reference']
    if not ref.get('quantity') or not ref.get('definition') or not ref.get('tolerance_reason'):raise ValueError('QOI identity/tolerance provenance required')
    number(ref['value'],'reference value');number(ref['relative_tolerance'],'reference tolerance',True)
    if case['model']!='hertz_spheres' and len(case['mesh_levels'])!=3:raise ValueError('exactly 3 controlled mesh levels required')
    for value in case['geometry'].values():number(value,'geometry',True)
    return True
