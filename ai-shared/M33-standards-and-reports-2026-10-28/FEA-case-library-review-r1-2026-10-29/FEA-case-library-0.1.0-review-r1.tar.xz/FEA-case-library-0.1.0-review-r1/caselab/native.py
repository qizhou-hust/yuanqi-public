"""Self-written Q8 benchmark deck generator and restricted independent readback.

Only CPS8 plane stress body force and CAX8 spherical pressure are supported.
Jacobian screening samples 3x3 Gauss points; it is not a certified curved-domain proof.
"""
import math
from collections import defaultdict
from .common import validate_case, sum_loads, number
from .reference import predict

G=[(-math.sqrt(3/5),5/9),(0.,8/9),(math.sqrt(3/5),5/9)]
def shape(r,s):
    return [-.25*(1-r)*(1-s)*(1+r+s),-.25*(1+r)*(1-s)*(1-r+s),
            -.25*(1+r)*(1+s)*(1-r-s),-.25*(1-r)*(1+s)*(1+r-s),
            .5*(1-r*r)*(1-s),.5*(1+r)*(1-s*s),.5*(1-r*r)*(1+s),.5*(1-r)*(1-s*s)]
def derivative(r,s):
    return ([.25*(1-s)*(2*r+s),.25*(1-s)*(2*r-s),.25*(1+s)*(2*r+s),.25*(1+s)*(2*r-s),
             -r*(1-s),.5*(1-s*s),-r*(1+s),-.5*(1-s*s)],
            [.25*(1-r)*(r+2*s),.25*(1+r)*(-r+2*s),.25*(1+r)*(r+2*s),.25*(1-r)*(-r+2*s),
             -.5*(1-r*r),-(1+r)*s,.5*(1-r*r),-(1-r)*s])
def jacobian(xy,r,s):
    dr,ds=derivative(r,s)
    dxdr=sum(dr[i]*xy[i][0] for i in range(8));dydr=sum(dr[i]*xy[i][1] for i in range(8))
    dxds=sum(ds[i]*xy[i][0] for i in range(8));dyds=sum(ds[i]*xy[i][1] for i in range(8))
    return dxdr*dyds-dxds*dydr

def model(case,level):
    validate_case(case);g=case['geometry'];mesh=case['mesh_levels'][level]
    nx,ny=mesh[:2]
    if any(type(n) is not int or n<2 for n in [nx,ny]):raise ValueError('invalid mesh')
    nodes={};lookup={}
    for j in range(2*ny+1):
        for i in range(2*nx+1):
            if i%2 and j%2:continue
            if case['model']=='cantilever_body_force':x=i*g['length_mm']/(2*nx);y=j*g['height_mm']/(2*ny)
            elif case['model']=='hollow_sphere_external_pressure':
                radius=g['inner_radius_mm']+(g['outer_radius_mm']-g['inner_radius_mm'])*i/(2*nx)
                theta=math.pi/2*j/(2*ny);x=radius*math.cos(theta);y=radius*math.sin(theta)
                if j==2*ny:x=0.
            else:raise ValueError('No native solver adapter for this model')
            nid=len(nodes)+1;nodes[nid]=[x,y,0.];lookup[i,j]=nid
    elements={}
    for j in range(ny):
        for i in range(nx):
            ids=[(2*i,2*j),(2*i+2,2*j),(2*i+2,2*j+2),(2*i,2*j+2),
                 (2*i+1,2*j),(2*i+2,2*j+1),(2*i+1,2*j+2),(2*i,2*j+1)]
            elements[len(elements)+1]=[lookup[k] for k in ids]
    loads=defaultdict(float)
    if case['model']=='cantilever_body_force':
        for element in elements.values():
            xy=[nodes[n] for n in element]
            for r,wr in G:
                for s,ws in G:
                    w=wr*ws*jacobian(xy,r,s)*g['width_mm']*case['loading']['force_density_N_per_mm3']
                    for n,N in zip(element,shape(r,s)):loads[n,2]-=w*N
        sets={'ALL':list(nodes),'LEFT':[lookup[0,j] for j in range(2*ny+1)],'TIP':[lookup[2*nx,j] for j in range(2*ny+1)]}
        bounds=[('LEFT',1,2,0.)];etype='CPS8';thickness=g['width_mm']
    else:
        # Integrate physical surface traction over each quadratic outer edge,
        # including 2*pi*r for CCX's full-circumference concentrated-force convention.
        for j in range(ny):
            ids=[lookup[2*nx,2*j],lookup[2*nx,2*j+2],lookup[2*nx,2*j+1]]
            for t,w in G:
                N=[.5*t*(t-1),.5*t*(t+1),1-t*t];dN=[t-.5,t+.5,-2*t]
                x=sum(N[k]*nodes[n][0] for k,n in enumerate(ids))
                dx=sum(dN[k]*nodes[n][0] for k,n in enumerate(ids));dy=sum(dN[k]*nodes[n][1] for k,n in enumerate(ids))
                fac=-case['loading']['external_pressure_MPa']*2*math.pi*x*w
                for k,n in enumerate(ids):loads[n,1]+=N[k]*dy*fac;loads[n,2]-=N[k]*dx*fac
        sets={'ALL':list(nodes),'AXIS':[lookup[i,2*ny] for i in range(2*nx+1)],'EQUATOR':[lookup[i,0] for i in range(2*nx+1)],
              'INNER':[lookup[0,j] for j in range(2*ny+1)],'OUTER':[lookup[2*nx,j] for j in range(2*ny+1)]}
        bounds=[('AXIS',1,1,0.),('EQUATOR',2,2,0.)];etype='CAX8';thickness=1.
    support=sorted({n for name,_,_,_ in bounds for n in sets[name]});sets['SUPPORT']=support
    return {'nodes':nodes,'elements':elements,'sets':sets,'bounds':bounds,'loads':[(n,d,v) for (n,d),v in sorted(loads.items()) if abs(v)>1e-18],
            'etype':etype,'thickness':thickness}

def generate(case,level):
    m=model(case,level);fmt=lambda v:format(v,'.14g');lines=['*HEADING',case['id']+' level '+str(level),'*NODE']
    lines += [','.join([str(n)]+[fmt(v) for v in xy]) for n,xy in m['nodes'].items()]
    lines+=['*ELEMENT,TYPE='+m['etype']+',ELSET=BODY']
    lines += [','.join(map(str,[e]+ns)) for e,ns in m['elements'].items()]
    for name,ns in m['sets'].items():
        lines+=['*NSET,NSET='+name]
        lines += [','.join(map(str,ns[i:i+16])) for i in range(0,len(ns),16)]
    lines+=['*MATERIAL,NAME=MAT','*ELASTIC',fmt(case['material']['E_MPa'])+','+fmt(case['material']['nu']),
            '*SOLID SECTION,ELSET=BODY,MATERIAL=MAT',fmt(m['thickness']),'*BOUNDARY']
    lines += [f'{name},{a},{b},{fmt(v)}' for name,a,b,v in m['bounds']]
    lines += ['*STEP','*STATIC','1,1','*CLOAD']
    lines += [f'{n},{d},{fmt(v)}' for n,d,v in m['loads']]
    lines += ['*NODE PRINT,NSET=ALL','U','*NODE PRINT,NSET=SUPPORT','RF',
              '*EL PRINT,ELSET=BODY','S','*NODE FILE','U','*EL FILE','S','*END STEP']
    return '\n'.join(lines)+'\n'

ALLOWED={'HEADING':set(),'NODE':set(),'ELEMENT':{'TYPE','ELSET'},'NSET':{'NSET'},'MATERIAL':{'NAME'},'ELASTIC':set(),
         'SOLID SECTION':{'ELSET','MATERIAL'},'BOUNDARY':set(),'STEP':set(),'STATIC':set(),'CLOAD':set(),
         'NODE PRINT':{'NSET'},'EL PRINT':{'ELSET'},'NODE FILE':set(),'EL FILE':set(),'END STEP':set()}
def parse_deck(text):
    blocks=[];b=None
    for raw in text.splitlines():
        line=raw.strip()
        if not line or line.startswith('**'):continue
        if line.startswith('*'):
            p=line[1:].upper().split(',');attrs=dict(x.split('=',1) if '=' in x else (x,'') for x in p[1:]);key=p[0]
            if key not in ALLOWED or set(attrs)-ALLOWED[key]:raise ValueError('Unsupported keyword/attribute '+line)
            b={'key':key,'attrs':attrs,'rows':[]};blocks.append(b)
        elif b is None:raise ValueError('data without keyword')
        else:b['rows'].append(line.split(','))
    nodes={};elements={};sets={};loads=[];bounds=[]
    for b in blocks:
        key=b['key']
        if key=='NODE':
            for row in b['rows']:
                n=int(row[0]);xy=[number(float(x),'coordinate') for x in row[1:]]
                if n in nodes or len(xy)!=3:raise ValueError('duplicate/invalid node')
                nodes[n]=xy
        elif key=='ELEMENT':
            for row in b['rows']:
                e=int(row[0]);ns=list(map(int,row[1:]))
                if e in elements or len(ns)!=8 or len(set(ns))!=8:raise ValueError('duplicate/invalid element')
                elements[e]=ns
        elif key=='NSET':
            name=b['attrs']['NSET']
            if name in sets:raise ValueError('duplicate set')
            sets[name]=[int(x) for row in b['rows'] for x in row]
            if len(sets[name])!=len(set(sets[name])):raise ValueError('duplicate set member')
        elif key=='CLOAD':loads.extend((int(r[0]),int(r[1]),number(float(r[2]),'load')) for r in b['rows'])
        elif key=='BOUNDARY':bounds.extend((r[0],int(r[1]),int(r[2]),number(float(r[3]),'prescribed value')) for r in b['rows'])
    return {'nodes':nodes,'elements':elements,'sets':sets,'loads':loads,'bounds':bounds,'blocks':blocks}

def supported_step_order(blocks):
    """The supported profile has model BCs, one STATIC load step, then outputs.

    Model data cannot be silently treated as active if it appears after the step.
    This is deliberately narrower than the full CalculiX step language.
    """
    keys=[b['key'] for b in blocks]
    if any(keys.count(k)!=1 for k in ['STEP','STATIC','CLOAD','END STEP']):return False
    start=keys.index('STEP');end=keys.index('END STEP')
    if end!=len(keys)-1 or end<=start+2:return False
    model_keys={'HEADING','NODE','ELEMENT','NSET','MATERIAL','ELASTIC','SOLID SECTION','BOUNDARY'}
    if not all(k in model_keys for k in keys[:start]):return False
    if keys[start+1:start+3]!=['STATIC','CLOAD']:return False
    if not all(k in {'NODE PRINT','EL PRINT','NODE FILE','EL FILE'} for k in keys[start+3:end]):return False
    return not blocks[start]['rows'] and not blocks[end]['rows']

def preflight(text,case,level):
    checks={};detail={}
    try:
        validate_case(case);d=parse_deck(text);nodes=d['nodes'];els=d['elements'];blocks=d['blocks'];g=case['geometry']
        of=lambda key:[b for b in blocks if b['key']==key]
        checks['nonempty']=bool(nodes and els and d['loads'])
        checks['references']=all(n in nodes for ns in els.values() for n in ns) and all(n in nodes for ns in d['sets'].values() for n in ns)
        checks['unique_load_dofs']=len({(n,di) for n,di,v in d['loads']})==len(d['loads'])
        checks['load_nodes_dofs']=all(n in nodes and di in [1,2] for n,di,v in d['loads'])
        # Bind the complete per-node load roster to this declared case and level.
        # Net force/moment alone cannot detect self-equilibrated added loading.
        # Compare serialized values, not a relaxed physical acceptance tolerance.
        expected_loads={(n,di):float(format(v,'.14g')) for n,di,v in model(case,level)['loads']}
        actual_loads={(n,di):v for n,di,v in d['loads']}
        checks['load_distribution']=checks['unique_load_dofs'] and actual_loads==expected_loads
        detail['load_distribution']={'actual_dofs':len(actual_loads),'expected_dofs':len(expected_loads),
            'definition':'Exact declared case/mesh consistent nodal roster at the 14-significant-digit deck serialization; separate from force/moment and formula validation'}
        checks['material']=len(of('MATERIAL'))==len(of('ELASTIC'))==len(of('SOLID SECTION'))==1 and of('MATERIAL')[0]['attrs']=={'NAME':'MAT'} and of('SOLID SECTION')[0]['attrs']=={'ELSET':'BODY','MATERIAL':'MAT'}
        E,nu=map(float,of('ELASTIC')[0]['rows'][0]);checks['material']=checks['material'] and E==case['material']['E_MPa'] and nu==case['material']['nu']
        etype='CPS8' if case['model']=='cantilever_body_force' else 'CAX8'
        checks['element_type']=len(of('ELEMENT'))==1 and of('ELEMENT')[0]['attrs']=={'TYPE':etype,'ELSET':'BODY'}
        checks['one_static_step']=len(of('STEP'))==len(of('STATIC'))==len(of('END STEP'))==1 and of('STATIC')[0]['rows']==[['1','1']]
        checks['step_order']=supported_step_order(blocks)
        checks['all_set']=set(d['sets'].get('ALL',[]))==set(nodes)
        t=float(of('SOLID SECTION')[0]['rows'][0][0]);checks['thickness']=t==(g['width_mm'] if etype=='CPS8' else 1.)
        eps=1e-9
        if etype=='CPS8':
            left={n for n,p in nodes.items() if abs(p[0])<eps};tip={n for n,p in nodes.items() if abs(p[0]-g['length_mm'])<eps}
            checks['geometry']=all(-eps<=p[0]<=g['length_mm']+eps and -eps<=p[1]<=g['height_mm']+eps and p[2]==0 for p in nodes.values())
            checks['boundary']=set(d['bounds'])=={('LEFT',1,2,0.)} and set(d['sets'].get('LEFT',[]))==left and bool(left)
            checks['qoi_set']=set(d['sets'].get('TIP',[]))==tip and bool(tip)
        else:
            axis={n for n,p in nodes.items() if abs(p[0])<eps};eq={n for n,p in nodes.items() if abs(p[1])<eps}
            checks['geometry']=all(p[0]>=-eps and p[1]>=-eps and g['inner_radius_mm']-eps<=math.hypot(*p[:2])<=g['outer_radius_mm']+eps for p in nodes.values())
            checks['boundary']=set(d['bounds'])=={('AXIS',1,1,0.),('EQUATOR',2,2,0.)} and set(d['sets'].get('AXIS',[]))==axis and set(d['sets'].get('EQUATOR',[]))==eq and bool(axis and eq)
            checks['qoi_set']=all(set(d['sets'].get(name,[]))=={n for n,p in nodes.items() if abs(math.hypot(*p[:2])-g[key])<eps} for name,key in [('INNER','inner_radius_mm'),('OUTER','outer_radius_mm')])
        support={n for name,a,b,v in d['bounds'] for n in d['sets'][name]}
        checks['support_set']=set(d['sets'].get('SUPPORT',[]))==support and bool(support)
        determinant=[jacobian([nodes[n] for n in ns],r,s) for ns in els.values() for r,_ in G for s,_ in G]
        checks['sampled_jacobian']=bool(determinant) and all(math.isfinite(x) and x>0 for x in determinant)
        detail['minimum_sampled_jacobian']=min(determinant)
        target=predict(case);actual=sum_loads(nodes,d['loads']);fscale=max(abs(x) for x in target['applied_force']);mscale=max(fscale,max(abs(x) for x in target['applied_moment']))
        ferr=max(abs(a-b) for a,b in zip(actual['force'],target['applied_force']))/fscale
        merr=max(abs(a-b) for a,b in zip(actual['moment'],target['applied_moment']))/mscale
        checks['force_moment']=ferr<1e-5 and merr<1e-5;detail.update(actual_load=actual,force_error_rel=ferr,moment_error_rel=merr)
        checks['output_requests']=any(b['attrs']=={'NSET':'ALL'} and b['rows']==[['U']] for b in of('NODE PRINT')) and any(b['attrs']=={'NSET':'SUPPORT'} and b['rows']==[['RF']] for b in of('NODE PRINT'))
    except (ValueError,KeyError,IndexError,TypeError,ZeroDivisionError) as e:
        checks['parse_supported']=False;detail['error']=str(e)
    return {'ready':bool(checks) and all(checks.values()),'checks':checks,'detail':detail,'engineering_accepted':False,
            'scope':'Restricted benchmark preflight, 3x3 sampled Q8 Jacobian; not arbitrary native model validation'}
