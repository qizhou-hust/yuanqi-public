"""Independent formulas; source transcripts are fixed separately in cases JSON."""
import math
from .common import validate_case

def predict(case):
    validate_case(case);g=case['geometry'];E=case['material']['E_MPa'];nu=case['material']['nu'];load=case['loading']
    if case['model']=='cantilever_body_force':
        L,H,B=g['length_mm'],g['height_mm'],g['width_mm'];density=load['force_density_N_per_mm3']
        q=density*H*B;I=B*H**3/12;G=E/(2*(1+nu));area=H*B
        bending=q*L**4/(8*E*I);shear=q*L**2/(2*(5/6)*G*area)
        return {'qoi':bending,'bending_tip_mm':bending,'timoshenko_tip_mm':bending+shear,
                'nominal_root_bending_MPa':q*L*L/2*(H/2)/I,
                'applied_force':[0,-q*L,0],'applied_moment':[0,0,-q*L*L/2],
                'scope':'Euler-Bernoulli uniform body force; Timoshenko is an auxiliary estimate; plane-stress clamp end effects remain separate'}
    if case['model']=='hollow_sphere_external_pressure':
        a,b=g['inner_radius_mm'],g['outer_radius_mm'];p=load['external_pressure_MPa']
        if b<=a:raise ValueError('outer radius must exceed inner')
        def u(r):return -b**3/(b**3-a**3)*((1-2*nu)*r+(1+nu)*a**3/(2*r*r))*p/E
        return {'qoi':-u(a),'inner_radial_displacement_mm':u(a),'outer_radial_displacement_mm':u(b),
                'applied_force':[-math.pi**2/2*p*b*b,-math.pi*p*b*b,0],'applied_moment':[0,0,0],
                'scope':'Upper hemispherical meridian, axisymmetry, external pressure; force_x is generalized radial integral over circumference, not Cartesian global resultant'}
    if case['model']=='hertz_spheres':
        r=g['radius_mm'];delta=load['total_approach_mm'];Estar=E/(2*(1-nu*nu));Rstar=r/2
        a=math.sqrt(Rstar*delta);p0=2*Estar*a/(math.pi*Rstar);F=4/3*Estar*math.sqrt(Rstar)*delta**1.5
        return {'qoi':p0,'contact_radius_mm':a,'peak_compressive_pressure_MPa':p0,'normal_force_N':F,
                'a_over_R':a/r,'elastic_energy_Nmm':2*F*delta/5,
                'scope':'Identical convex spheres, classical smooth frictionless Hertz asymptote; published case has finite a/R and is not small-patch proof'}
    raise ValueError('unsupported reference')
