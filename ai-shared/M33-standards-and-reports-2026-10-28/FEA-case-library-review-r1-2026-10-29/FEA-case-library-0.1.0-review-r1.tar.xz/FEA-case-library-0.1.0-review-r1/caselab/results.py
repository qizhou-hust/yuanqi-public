"""Strict raw-field extraction for the new one-step benchmark profiles."""
import math
import re
from .common import sum_loads
from .native import parse_deck
from .reference import predict

def read_nodal(text,kind,set_name,expected_nodes,time):
    found=[];active=None
    for line in text.splitlines():
        row=line.strip()
        if not row:continue
        if re.match(r'^[A-Za-z*]',row):
            match=re.search(r'for set\s+(\S+)\s+and time\s+([-+\d.eED]+)',row,re.I)
            active=None
            if row.lower().startswith(kind.lower()+' ') and match and match[1].upper()==set_name.upper():
                active={'time':float(match[2].replace('D','E')),'rows':[]};found.append(active)
            continue
        if active is not None:
            vals=row.split()
            if len(vals)!=4:raise ValueError('wrong nodal row width')
            active['rows'].append((int(vals[0]),[float(x.replace('D','E')) for x in vals[1:]]))
    if not found:raise ValueError('missing field '+kind+'/'+set_name)
    final=[f for f in found if math.isclose(f['time'],time,rel_tol=0,abs_tol=1e-9)]
    if len(final)>1:raise ValueError('duplicate final field block '+kind+'/'+set_name)
    f=found[-1]
    if not math.isclose(f['time'],time,rel_tol=0,abs_tol=1e-9):raise ValueError('wrong final field time')
    if not expected_nodes or len(f['rows'])!=len(expected_nodes):raise ValueError('missing/duplicate nodal coverage')
    result={n:values for n,values in f['rows']}
    if set(result)!=set(expected_nodes):raise ValueError('wrong nodal identities')
    if not all(math.isfinite(x) for vs in result.values() for x in vs):raise ValueError('nonfinite result')
    return result

def extract(text,deck,case):
    d=parse_deck(deck);U=read_nodal(text,'displacements','ALL',set(d['nodes']),1.)
    RF=read_nodal(text,'forces','SUPPORT',set(d['sets']['SUPPORT']),1.)
    g=case['geometry'];theory=predict(case)
    if case['model']=='cantilever_body_force':
        node=min(d['sets']['TIP'],key=lambda n:abs(d['nodes'][n][1]-g['height_mm']/2))
        actual=-U[node][1];qois={'tip_center_inward_mm':actual,'tip_node':node,'tip_position':d['nodes'][node]}
    else:
        node=min(d['sets']['INNER'],key=lambda n:abs(d['nodes'][n][1]))
        outer=min(d['sets']['OUTER'],key=lambda n:abs(d['nodes'][n][1]))
        actual=-U[node][0];qois={'inner_equator_inward_mm':actual,'outer_equator_inward_mm':-U[outer][0],
                               'inner_node':node,'inner_position':d['nodes'][node]}
    rfloads=[(n,j+1,v) for n,vs in RF.items() for j,v in enumerate(vs)]
    rf=sum_loads(d['nodes'],rfloads)
    # Preserve raw RF. Do not infer a universally valid 2D/axisym RF scale here.
    return {'qoi':actual,'qois':qois,'analytical':theory,'raw_support_RF':rf,
            'nodal_coverage':{'U':len(U),'RF':len(RF),'complete':True,'final_time':1.},
            'public_reference':case['reference'],'relative_error':abs(actual-case['reference']['value'])/abs(case['reference']['value']),
            'reference_gate_pass':abs(actual-case['reference']['value'])/abs(case['reference']['value'])<=case['reference']['relative_tolerance'],
            'secondary_qoi_status':{'outer_equator_inward_mm':'REPORTED_NOT_INDEPENDENTLY_GATED'} if case['model']=='hollow_sphere_external_pressure' else {},
            'raw_RF_interpretation':'Requires profile-specific convention; no automatic general acceptance',
            'engineering_accepted':False}
