import os
import re
import subprocess
import time
from datetime import datetime,timezone
from pathlib import Path
from .common import sha,write,digest
from .native import preflight,generate
from .results import extract

def linux_path(path):
    s=str(Path(path).resolve()).replace('\\','/')
    if len(s)<3 or s[1]!=':':raise ValueError('Windows drive path required by WSL adapter')
    return '/mnt/'+s[0].lower()+s[2:]

def runtime_check(config):
    if config.get('adapter')!='wsl_calculix':raise ValueError('Unsupported runtime')
    files=config.get('identity_files',[])
    if not files:raise ValueError('Missing solver identity')
    if not config.get('executable'):raise ValueError('Missing executable path')
    executable=Path(config['executable']).resolve()
    identities={}
    for f in files:
        path=Path(f['path']).resolve()
        if path in identities:raise ValueError('Duplicate runtime identity path: '+str(path))
        identities[path]=f['sha256']
        if sha(path)!=f['sha256']:raise ValueError('Solver/library identity changed: '+str(path))
    if executable not in identities:raise ValueError('Actual executable is not bound by runtime identity_files')
    return True

def solve(case,level,folder,config):
    runtime_check(config);folder=Path(folder).resolve();folder.mkdir(parents=True,exist_ok=False)
    deck=generate(case,level);before=preflight(deck,case,level);write(folder/'preflight.json',before)
    if not before['ready']:raise ValueError('Preflight rejected: '+str(before))
    inp=folder/'job.inp';inp.write_text(deck,encoding='ascii');write(folder/'case.json',case)
    identity=sha(inp);reread=preflight(inp.read_text(),case,level)
    if not reread['ready']:raise ValueError('Exported model rejected')
    args=['wsl.exe','-d',config['distribution'],'--cd',linux_path(folder),'--','env','OMP_NUM_THREADS=2',
          'CCX_NPROC_EQUATION_SOLVER=2','CCX_NPROC_RESULTS=2','GFORTRAN_UNBUFFERED_ALL=1',
          'LD_LIBRARY_PATH='+':'.join(linux_path(p) for p in config['library_directories']),linux_path(config['executable']),'-i','job']
    t=time.monotonic();started=datetime.now(timezone.utc).isoformat();timedout=False;code=None
    with (folder/'solver.log').open('wb') as log:
        try:
            p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=180,shell=False,
                             creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
            code=p.returncode
        except subprocess.TimeoutExpired:timedout=True
    log=(folder/'solver.log').read_text(errors='replace');sta=[]
    if (folder/'job.sta').exists():
        for line in (folder/'job.sta').read_text().splitlines():
            v=line.split()
            try:
                if len(v)==7:sta.append([float(x) for x in v])
            except ValueError:pass
    last=sta[-1] if sta else []
    complete=type(code) is int and code==0 and not timedout and 'Job finished' in log and not re.search(r'\*ERROR|fatal|segmentation fault',log,re.I)
    complete=bool(complete and last and last[0]==1 and abs(last[4]-1)<1e-8 and abs(last[5]-1)<1e-8 and identity==sha(inp))
    record={'schema':'case-library.run/1','case_id':case['id'],'mesh_level':level,'started_utc':started,'wall_s':time.monotonic()-t,
            'returncode':code,'timed_out':timedout,'complete':complete,'input_sha256':identity,'case_sha256':digest(case),
            'runtime':config,'command':args,'sta_final':last,'engineering_accepted':False}
    if complete:
        try:record['result']=extract((folder/'job.dat').read_text(),deck,case)
        except (ValueError,OSError) as e:record['extraction_error']=str(e);record['complete']=False
    record['artifacts']={p.name:sha(p) for p in folder.iterdir() if p.is_file()}
    write(folder/'run.json',record)
    print(case['id'],level,'complete',record['complete'],'qoi',record.get('result',{}).get('qoi'),'error',record.get('result',{}).get('relative_error'),flush=True)
    return record
