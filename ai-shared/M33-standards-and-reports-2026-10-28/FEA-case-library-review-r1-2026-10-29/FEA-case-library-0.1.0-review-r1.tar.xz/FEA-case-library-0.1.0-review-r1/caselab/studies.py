"""Replay fixed raw evidence. Passing this audit does not accept an engineering model."""
import math
import re
from pathlib import Path
from .common import read, write, sha, digest
from .native import preflight, generate, parse_deck
from .results import extract, read_nodal

RUNS = {
 'beam-original': ('cases/public/comet-beam.json', ['results/beam-original/level-'+str(i) for i in range(3)]),
 'beam-thin': ('cases/diagnostic/beam-t0.01.json', ['results/beam-thin-completion/level-0','results/beam-t0.01/level-1','results/beam-thin-completion/level-2']),
 'beam-thickness-diagnostic': ('cases/diagnostic/beam-t0.1.json', ['results/beam-t0.1/level-1']),
 'sphere-qualified': ('cases/public/comet-sphere.json', ['results/sphere-qualified/level-'+str(i) for i in range(3)]),
}

def need(ok, text):
    if not ok: raise ValueError(text)

def replay_run(root, folder, canonical):
    p=root/folder; run=read(p/'run.json'); case=read(p/'case.json'); deck=(p/'job.inp').read_text()
    need(digest(case)==digest(canonical)==run['case_sha256'], 'Case identity: '+folder)
    need(sha(p/'job.inp')==run['input_sha256'], 'Deck identity: '+folder)
    need(set(run['artifacts'])=={f.name for f in p.iterdir() if f.is_file() and f.name!='run.json'}, 'Exact artifact roster: '+folder)
    for name, checksum in run['artifacts'].items():
        need(Path(name).name==name and sha(p/name)==checksum, 'Raw artifact identity: '+folder+'/'+name)
    need(run['complete'] and run['returncode']==0 and run['timed_out'] is False, 'Historical process completion: '+folder)
    log=(p/'solver.log').read_text(errors='replace')
    need('Job finished' in log and not re.search(r'\*ERROR|fatal|segmentation fault',log,re.I), 'Solver log: '+folder)
    rows=[]
    for line in (p/'job.sta').read_text().splitlines():
        vals=line.split()
        if len(vals)!=7:continue
        try:rows.append([float(v) for v in vals])
        except ValueError:pass
    need(bool(rows) and rows[-1]==run['sta_final'] and rows[-1][0]==1 and rows[-1][4:6]==[1.,1.], 'Final state: '+folder)
    check=preflight(deck,case,run['mesh_level']); need(check['ready'], 'Current preflight: '+folder+' '+str(check))
    result=extract((p/'job.dat').read_text(),deck,case)
    need(result['qoi']==run['result']['qoi'], 'Raw QOI/stored value conflict: '+folder)
    need(not run['engineering_accepted'] and not result['engineering_accepted'], 'No implied engineering approval')
    supplemental={}
    if case['model']=='hollow_sphere_external_pressure':
        target=case['reference']['outer_equator_inward_mm']; actual=result['qois']['outer_equator_inward_mm']
        supplemental['outer_displacement']={'value':actual,'reference':target,'relative_error':abs(actual-target)/abs(target),
            'status':'OBSERVATION_ONLY','reason':'Outer value was recorded but not a separate preregistered gate; do not retroactively accept it.'}
        supplemental['balance']={'status':'UNKNOWN','reason':'RF reports expanded sector. Full-circumference force input and generalized radial integral cannot be combined as ordinary Cartesian forces.'}
    else:
        # Diagnostic only: this is not promoted to a gate until RF convention is independently closed.
        d=parse_deck(deck); support=set(d['sets']['SUPPORT']); support_load=sum(v for n,di,v in d['loads'] if n in support and di==2)
        total=sum(v for n,di,v in d['loads'] if di==2); raw=result['raw_support_RF']['force'][1]
        supplemental['balance']={'status':'UNKNOWN','raw_RF_y':raw,'support_CLOAD_y':support_load,'total_CLOAD_y':total,
            'candidate_reaction_RF_minus_support_CLOAD':raw-support_load,
            'candidate_relative_residual':abs(raw-support_load+total)/abs(total),
            'reason':'Candidate limited to consistent nodal body-force CPS8 profile; not a general RF convention or accepted balance gate.'}
    return {'folder':folder,'mesh_level':run['mesh_level'],'qoi':result['qoi'],'relative_error':result['relative_error'],
        'reference_gate_pass':result['reference_gate_pass'],'preflight_pass':True,'raw_coverage':result['nodal_coverage'],
        'input_sha256':run['input_sha256'],'supplemental':supplemental,'engineering_accepted':False}

def replay_public(root):
    root=Path(root); studies={}
    for name,(path,folders) in RUNS.items():
        case=read(root/path); rows=[replay_run(root,f,case) for f in folders]; values=[r['qoi'] for r in rows]
        need([r['mesh_level'] for r in rows]==([1] if len(rows)==1 else [0,1,2]), 'Exact mesh roster')
        item={'physical_case': 'PUB-COMET-SPHERE' if 'sphere' in name else 'PUB-COMET-BEAM', 'runs':rows,
              'all_displacement_reference_gates_pass':all(r['reference_gate_pass'] for r in rows),
              'overall_physical_validation':'INCOMPLETE_BALANCE_AND_STRESS_NOT_QUALIFIED', 'engineering_accepted':False}
        if len(values)==3:
            d1=values[0]-values[1];d2=values[1]-values[2]
            order=math.log(abs(d1/d2),2) if d1*d2>0 and abs(d1)>abs(d2)>0 else None
            item['mesh_study']={'last_relative_change':abs(values[2]-values[1])/abs(values[2]),'observed_order':order,
                'status':'monotonic_scalar_trend_only' if order is not None else 'UNKNOWN_oscillating_or_print_resolution',
                'Richardson_acceptance':False}
        studies[name]=item
    need(not studies['beam-original']['all_displacement_reference_gates_pass'], 'Original thickness failure must stay visible')
    need(studies['beam-thin']['all_displacement_reference_gates_pass'] and studies['sphere-qualified']['all_displacement_reference_gates_pass'], 'Qualified displacement comparisons')
    coarse=read(root/'cases/diagnostic/sphere-coarse-rejected.json'); rejected=preflight(generate(coarse,0),coarse,0)
    need(not rejected['ready'] and not rejected['checks']['force_moment'], 'Coarse geometry-load rejection must remain')
    need(not (root/'results/sphere-original/level-0/run.json').exists(), 'Rejected coarse mesh was not solved')
    need(set(studies)==set(RUNS) and sum(len(v['runs']) for v in studies.values())==10,'Exact 10-job roster')
    return {'new_physical_FE_cases':2,'actual_solver_jobs':10,'studies':studies,'rejected_coarse_mesh':rejected,
        'solver_executed_by_replay':False,'engineering_accepted':False}
