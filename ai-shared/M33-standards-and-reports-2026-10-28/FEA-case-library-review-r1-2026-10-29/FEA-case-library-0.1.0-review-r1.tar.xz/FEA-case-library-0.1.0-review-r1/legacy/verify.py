"""Portable historical evidence verification/materialization; stdlib only.

This script never launches a solver and does not upgrade historical acceptance.
"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json
import shutil


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def inside(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError('Path escapes legacy root: ' + relative)
    return path


def verify(root):
    root = Path(root).resolve()
    index = read(root / 'index.json')
    errors = []
    case_ids = {'M37-L0-tension','M37-L0-contact','M37-L1','M37-L3','M33-TR30-7','M33-TR30-8'}
    case_ids.update('M37-L2-P%02d' % i for i in range(1,15))
    if {c['id'] for c in index['cases']} != case_ids or len(index['cases']) != 20:
        errors.append('Exact set of 20 physical cases is missing or duplicated')
    rows = index['artifacts'] + index['cases'] + index['jobs']
    for row in rows:
        try:
            p = inside(root,row['path'])
            if not p.is_file() or p.stat().st_size != row['bytes'] or sha(p) != row['sha256']:
                errors.append('Missing or changed: ' + row['path'])
        except (OSError,ValueError) as exc:
            errors.append(str(exc))
    artifact_by_hash = {a['sha256']:a for a in index['artifacts']}
    if len(artifact_by_hash) != len(index['artifacts']):
        errors.append('Duplicate content stored as separate artifacts')
    actual_artifacts = {p.relative_to(root).as_posix() for p in (root/'artifacts').rglob('*') if p.is_file()}
    if actual_artifacts != {a['path'] for a in index['artifacts']}:
        errors.append('Unindexed or missing artifact files')
    if any(p.suffix.lower()=='.zip' for p in root.rglob('*') if p.is_file()):
        errors.append('Nested archive found')
    jobs = [read(inside(root,j['path'])) for j in index['jobs']]
    baseline = [j for j in jobs if j['scope']=='baseline']
    if len(baseline)!=82:
        errors.append('Original M37 baseline must have all 82 entries')
    expected_baseline_ids = {
        *(f'L0_patch_{el}_h{i}' for el in ('CPE6','CPE8') for i in range(3)),
        *(f'L0c_{method}_h{i}' for method in ('penalty','mortar') for i in range(2)),
        *(f'L1_mortar_d{d}' for d in (8,12,18)),
        *(f'L1_penalty_d{d}_a10' for d in (8,12,18)),
        'L1_penalty_d18_a5','L1_penalty_d18_a20',
        *(f'L2_P{i:02d}_d{d}' for i in range(1,15) for d in (8,12,18)),
        *(f'L3_C001_G1_ph{i:02d}_d12' for i in range(16)),
    }
    found_baseline_ids = {j['source_job_id'] for j in baseline}
    # C-point IDs are explicit in the historical source; verify their group
    # count without inventing a naming alias for those remaining six entries.
    if not expected_baseline_ids.issubset(found_baseline_ids) or len(found_baseline_ids-expected_baseline_ids)!=6:
        errors.append('Baseline mesh/phase set is incomplete')
    for job in jobs:
        if job['recomputed_this_round']:
            errors.append('Historical job incorrectly marked recomputed: ' + job['id'])
        if not set(job['case_ids']).issubset(case_ids):
            errors.append('Unknown case mapping: ' + job['id'])
        if job.get('required_artifacts_missing'):
            errors.append('Required raw missing: ' + job['id'])
        for ref in job['artifacts']:
            known = artifact_by_hash.get(ref['sha256'])
            if not known or known['path']!=ref['path'] or known['bytes']!=ref['bytes']:
                errors.append('Unbound job artifact: ' + job['id'])
    periodic = [j for j in jobs if j['scope']=='periodic-diagnostic']
    if {j['source_job_id'] for j in periodic} != {f'L3_C001_G1_ph{i:02d}_d12' for i in range(16)}:
        errors.append('Corrected phase evidence is incomplete')
    for phase in (10,11):
        old = next((j for j in baseline if j['source_job_id']==f'L3_C001_G1_ph{phase}_d12'),None)
        new = next((j for j in jobs if j['id']==f'repeat__L3_C001_G1_ph{phase}_d12'),None)
        if not old or not new or old['returncode_as_recorded'] is not None or new['returncode_as_recorded']!=0:
            errors.append('Original null/repeat actual exit-code boundary changed')
    never_started = [j for j in baseline if j['solver_started_as_recorded'] is False]
    if len(never_started)!=9:
        errors.append('Expected nine original explicitly unstarted jobs')
    for job in never_started:
        if any(Path(a['logical_path']).suffix in {'.dat','.sta','.log'} for a in job['artifacts']):
            errors.append('Unexpected result output on unstarted job: ' + job['id'])
    commercial = [j for j in jobs if j['native_format']=='KISSsoft Z012']
    for job in commercial:
        extensions = {Path(a['logical_path']).suffix.lower() for a in job['artifacts']}
        if not {'.z12','.pdf','.rtf','.csv'}.issubset(extensions) or job['historical_status']!='NOT_ACCEPTED':
            errors.append('Commercial native/report missing or acceptance changed: ' + job['id'])
    source_map = read(root/'source-map.json')['mappings']
    for mapping in source_map:
        known = artifact_by_hash.get(mapping['sha256'])
        if not known or 'legacy/'+known['path']!=mapping['destination']:
            errors.append('Source mapping destination mismatch')
    return {'schema':'case-library.legacy-verification/v1','passed':not errors,'errors':errors,
        'cases':len(index['cases']),'historical_entries':len(jobs),'raw_artifacts':len(index['artifacts']),
        'source_mappings':len(source_map),'bytes_verified':sum(a['bytes'] for a in index['artifacts']),
        'scope_counts':dict(Counter(j['scope'] for j in jobs)),
        'all_14_L2_points_with_3_meshes':True if not errors else None,
        'original_phase_entries':16,'corrected_phase_entries':len(periodic),
        'original_unstarted_entries':len(never_started), 'solver_executed':False,
        'engineering_accepted':False,'scope':'File identity and historical coverage only; no new FE or KISSsoft computation.'}


def materialize(root, job_id, output):
    root = Path(root).resolve()
    index = read(root/'index.json')
    matches = [row for row in index['jobs'] if row['id']==job_id]
    if len(matches)!=1:
        raise ValueError('Unknown or non-unique job id')
    job = read(inside(root,matches[0]['path']))
    output = Path(output).resolve()
    if output.exists():
        raise FileExistsError('Output folder must not already exist')
    # Verify before any write. Preserve filenames needed by native readers.
    sources = []
    for ref in job['artifacts']:
        path = inside(root,ref['path'])
        if sha(path)!=ref['sha256']:
            raise ValueError('Artifact changed')
        name = Path(ref['logical_path']).name
        if name in {item[1] for item in sources}:
            raise ValueError('Duplicate logical filename')
        sources.append((path,name))
    output.mkdir(parents=True,exist_ok=False)
    for path,name in sources:
        shutil.copyfile(path,output/name)
    (output/'historical-job.json').write_text(json.dumps(job,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    return {'materialized':job_id,'files':len(sources),'path':str(output),'solver_executed':False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--output',type=Path,help='Optional verification JSON output')
    parser.add_argument('--materialize-job')
    parser.add_argument('--destination',type=Path)
    args = parser.parse_args()
    if args.materialize_job:
        if not args.destination:
            parser.error('--destination is required for materialization')
        report = materialize(args.root,args.materialize_job,args.destination)
    else:
        report = verify(args.root)
    if args.output:
        args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if report.get('passed') is False:
        raise SystemExit(1)


if __name__=='__main__':
    main()
