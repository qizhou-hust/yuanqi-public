# 公开案例目录的机器读取与打包

`sources.json` 是来源清单，schema 为 `public-fea-case-sources/1.0`。`cases` 是数组，**不是**以案例 ID 为键的字典。推荐按 ID 建索引，不依赖数组顺序：

```python
import json
from pathlib import Path

root = Path(".")
manifest = json.loads((root / "research/sources.json").read_text(encoding="utf-8"))
sources_by_id = {case["id"]: case for case in manifest["cases"]}
assert len(sources_by_id) == manifest["public_case_count"] == 5

index = json.loads((root / "cases/catalog/index.json").read_text(encoding="utf-8"))
for entry in index["entries"]:
    source = sources_by_id[entry["physical_case_id"]]
    contract = json.loads((root / entry["contract"]).read_text(encoding="utf-8"))
    # entry.contract_kind distinguishes source-catalog contracts from runnable cases.
    if contract.get("schema") == "case-library.catalog/1":
        assert contract["source"]["record_id"] == source["id"]
        expected = contract["source_expected"]
        if not contract["adapter"]["run_eligible"]:
            # Keep UNSUPPORTED / NOT_RUN. Do not pass to the static FE runner.
            continue
```

三个新增契约是 `case-library.catalog/1`；它们不伪造运行所需的网格级别、数值容差或 native deck。现有 `cases/public/` 是另一种已支持的运行契约，两类必须根据 `contract_kind`/`schema` 分流。目录条目有原始来源几何、材料、边界、载荷、预期 QOI、单位解释、URL/commit/hash/许可；但提供来源值不等于完成 adapter 或求解。

| 路径 | 核心字段 | 允许的状态 |
|---|---|---|
| `cases/catalog/aster-ssnv104b-hertz.json` | `source_expected` 中有 p0、a、原源码节点 SIYY；`analytic_verification.record` 指向解析复核 | 解析标量可 PASS；FE adapter UNSUPPORTED，FE NOT_RUN |
| `cases/catalog/ccx-cook-us3.json` | node1 Uy = 22.31520；US3/USER SECTION 与等节点力定义 | 源回归参考，adapter UNSUPPORTED，FE NOT_RUN |
| `cases/catalog/ccx-beam8f-modal.json` | 十阶 `source_expected` 数组；eigenvalue/omega/frequency 分字段 | 源回归参考，adapter UNSUPPORTED，FE NOT_RUN |
| `cases/catalog/index.json` | 5 个唯一 `physical_case_id` 与实施契约路径 | 公开物理案例总数=5；不声称 COMET 当前运行状态 |

只按唯一 `physical_case_id` 计公开物理案例。三级网格、厚度诊断、粗网格载荷面拒绝、源接触算法变体都归到原物理案例，不能加进“公开案例总数”。每次 solver job 仍可在独立 results ledger 中单独计数。

`source_acceptance_tolerance` 是源明确给出的验收口径；没有来源则为 null。三个新条目的 `local_FE_acceptance_tolerance` 均为 null。Hertz 的源 7% 只对应源 RESU2 的 `SIGM_ELNO/SIYY @ N291/M31` 对解析 p0，不可移作新 CCX native pressure 的门。

Hertz 解析复核以两种算式组装得到同一数值：路径 A 是原 p0/a 公式；路径 B 用有效 E*/R*，先计算接触力，再由压力分布积分关系求 p0。这验证算术与来源转录，不能当第二个独立物理理论。与印刷 -2798.3 MPa 对拍时用半个最后小数位 0.05 MPa；其身份是**显示取整核验**，不是 FE 容差。报告中的 `arithmetic_status=PASS` 不覆盖 `a/R=0.2` 的适用限制，也不会改变 `local_FE_status=NOT_RUN`。

无网络、无第三方源码缓存即可重复检查：

```text
python -B research/build_catalog.py --check
```

命令重算 Hertz 标量、核对三份契约和总目录与来源清单一致，并检查已保存文件是否陈旧；不会写入文件或执行 solver。它也不会重新下载并鉴定 16 个第三方源文件，原来源读取/哈希证据仍在 `sources.json`。需要刷新来源清单时应先重新执行真实来源审查，不能仅为消除哈希不一致而改验收值。

正式包的允许文件在 `research/PACKAGE-CONTENTS.json`。该文件的 `required_research_files` 与 `required_catalog_files` 都是相对案例库根目录的路径。主路的运行源码、两份 runnable COMET 契约、原始 solver 结果与 replay gate 应另按主路清单加入。不要打包 `research/cache/` 或把第三方完整源码/网页/报告混入自有实现。当前来源全量重建脚本 `build_source_manifest.py` 需要本地缓存，仅作本地审计工具；正式包使用自含的 `build_catalog.py --check`。
