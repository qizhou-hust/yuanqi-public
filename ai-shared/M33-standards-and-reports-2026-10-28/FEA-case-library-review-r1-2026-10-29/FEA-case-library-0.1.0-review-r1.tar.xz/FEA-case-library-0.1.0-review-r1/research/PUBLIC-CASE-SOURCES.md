# 公开 FEA 案例来源与数值核验

本轮找到 **5 个不同的公开案例**：2 个 COMET 线弹性案例可作为新 CCX 移植计算的物理基准；2 个官方 CalculiX 案例有完整原始输入和公开回归输出；1 个 Code_Aster 接触例提供完整物理参数及 Hertz 解析参考。这里完成的是来源核验和标量公式重算，**没有运行第三方示例程序或任何 FE 求解器**。实际网格、CCX 运行及数值验收由案例库主流程独立记录。

`sources.json` 保存 5 个完整来源契约、16 个所用源文件的 URL/读取时间/SHA-256、39 项通过的读取及标量核验。COMET 两份优先接入契约另存为 `comet-cantilever.json`、`comet-hollow-sphere.json`。全局参考不得被当前实现计算结果覆盖。

后续接入补充：`cases/catalog/` 已提供 Hertz、Cook US3、beam8f 三份机器可读目录契约和五个物理案例的唯一 ID 索引；三例 FE 均保持 UNSUPPORTED / NOT_RUN。`reference-checks.json` 另保存 Hertz 的 4 项独立算式组装/显示取整核验，全部通过，但不构成接触 FE 验收。机器读取与无缓存重放见 `CATALOG-READING.md`，正式包允许文件见 `PACKAGE-CONTENTS.json`。

| 案例 | 公开输入/参考完整性 | 本轮可核对数值 | 应如何使用 |
|---|---|---|---|
| COMET 2D 自重悬臂 | 页面与完整 Python 脚本；完整连续体物理条件 | 端部向下挠度：公开 FE 0.0058638；梁理论 0.005859375 | CPS8 移植；原来源为 P2 三角形。梁理论是细长梁近似 |
| COMET 外压空心球 | 页面与完整 Python 脚本；完整物理条件和精确解 | 赤道径向位移：内 -0.002089360465116279；外 -0.0018386627906976747 | CAX8 移植；同一小应变球体问题的精确解 |
| CalculiX Cook US3 | 完整原生 `.inp` 与 `.dat.ref` | 节点 1 Uy = 22.31520 | 固定离散的软件回归；US3 适配待完成 |
| Code_Aster SSNV104B | 公开物理参数、解析解、命令文件；原 MED 网格未下载 | Hertz p0 = -2798.3286697476105 MPa；a = 10 mm | 接触理论与适用边界；不能据此认定 CCX 接触通过 |
| CalculiX beam8f 模态梁 | 完整原生 `.inp` 与 `.dat.ref` | f1 = 13798.13、f2 = 19852.05 cycles/time；共 10 阶 | 固定离散的软件回归；不是静力悬臂例 |

## 1. COMET：二维平面应力自重悬臂

来源：[2D linear elasticity](https://comet-fenics.readthedocs.io/en/latest/demo/elasticity/2D_elasticity.py.html)，作者 Jeremy Bleyer；[完整来源脚本](https://comet-fenics.readthedocs.io/en/latest/_downloads/ecd8b7a54a1d71e48d814bfebb794d01/2D_elasticity.py)。页面及脚本声明 CC BY-SA 4.0。ReadTheDocs 元数据给出提交短号 `50fcd879`、构建时间 2022-09-01；原仓库为 `gitlab.enpc.fr/jeremy.bleyer/comet-fenics`。全长提交查询遇到 TLS 证书链错误，没有关闭证书检查；来源按实际取得字节的 SHA-256 固定。

几何是 `[0,25] × [0,1]` 矩形，E = 100000、ν = 0.3，小应变平面应力。`x=0` 固定 ux = uy = 0，其余边界无施加面力；全域体力 `(fx,fy)=(0,-0.001)`。源离散为 Nx = 250、Ny = 10 的 crossed triangles，二次位移插值。

源文没有声明 mm/N 单位。本案例库可透明解释为 mm、N、MPa、体力 N/mm³，取单位厚度 1 mm；这属于本地一致单位解释。源程序是单位厚度二维方程，不能冒称作者给定了一个三维厚度。

QOI 是 `-uy(25,0.5)`。公开 FE 输出 `5.8638e-3`，公开梁理论显示 `5.8594e-3`。独立按 `q=fv·H·t=0.001`、`I=t·H³/12=1/12` 重算：

```text
delta_EB = q L^4 / (8 E I) = 0.005859375
Fy = -fv H t L = -0.025
Mz_about_origin = Fy L/2 = -0.3125
```

源说明“0.07% difference”是观察到的比较结果，不是验收容差。用其已取整 FE 数与本轮精确梁值计算是 0.07552%；不能把 0.07% 定义成外部硬门。

注意源代码把梁值写成 `3*rho_g*L**4/2/E/H**3`。固定 **H=1** 时它与上式一致；若改变 H、仍把 `rho_g` 当体力密度，则正确的截面积因子不能遗漏。因此只冻结原参数，不能把源码表达式泛化为任意 H 的体力梁公式。

CPS8 是本地离散选择；把体力替换成端力，或改成有限宽度 C3D8I 三维梁，都会改变案例。原例只提供挠度参考，不能拿夹持角点最大应力当已验证基准。

## 2. COMET：外压空心球，第一组光滑对称边界

来源：[Axisymmetric formulation for elastic structures of revolution](https://comet-fenics.readthedocs.io/en/latest/demo/elasticity/axisymmetric_elasticity.html)；[完整来源脚本](https://comet-fenics.readthedocs.io/en/latest/_downloads/dcfb9003c82832d12d1686803e96918f/axisymmetric_elasticity.py)。作者、许可和提交元数据同上。

实际三维对象是空心半球，经赤道对称代表完整空心球。其 `(r,z)` 子午截面为 `r≥0,z≥0,9≤sqrt(r²+z²)≤11`。Ri = 9、Re = 11、E = 100000、ν = 0.3；外球面均匀压力 p = 10、方向向内，内球面自由。`z=0` 仅约束 uz = 0；`r=0` 仅约束 ur = 0。来源采用 mshr 圆边界 100 段、网格参数 40、CG 二次位移。

虽然原文把截面描述为“quarter of a hollow cylinder”，旋转后的物体与解都是**球**。它不是 Lamé 厚壁圆筒。命名单位同样未由源文指定，可采用 mm/N/MPa 一致解释。

令 `R=sqrt(r²+z²)` 为球心距离，球径向位移为：

```text
u_s(R) = -Re³/(Re³-Ri³) · [(1-2ν)R + (1+ν)Ri³/(2R²)] · p/E
ur(r,z) = u_s(R) r/R
uz(r,z) = u_s(R) z/R
```

| QOI | 本轮独立求值：向外为正 | 源精确解显示：向内为正 | 源 FE 显示：向内为正 |
|---|---:|---:|---:|
| 赤道内面 `(r,z)=(9,0)` 的 ur | -0.002089360465116279 | 0.0020894 | 0.0020879 |
| 赤道外面 `(r,z)=(11,0)` 的 ur | -0.0018386627906976747 | 0.0018387 | 0.0018375 |

源公式旁的 `uz=0` 不能解释为轴对称域内所有位置的全局 z 位移均为零；在赤道 QOI 点它成立，在其他位置必须按上面的向量映射。只使用源第一组边界；后续“z=0 fully clamped”例还固定 ur，已经是不同的问题，不适用此解析解。

源弱式在两边约去了共同 `2π`，保留 r 权重。移植时的全周力积分必须明确角向度量，不能把径向广义合力当全局 Cartesian 合力。来源没有给出验收容差。三级 CAX8 网格、边界几何近似和容差属于本地选择，应单独记录。

## 3. CalculiX：Cook 锥形悬臂，US3 固定离散回归

官方仓库提交 `9e4fc4a856259ebfae0d7a2659c2c4a8030fe542`：

- [完整输入 lin_stat_cooks_beam_128.inp](https://raw.githubusercontent.com/Dhondtguido/CalculiX/9e4fc4a856259ebfae0d7a2659c2c4a8030fe542/test/lin_stat_cooks_beam_128.inp)
- [公开输出 lin_stat_cooks_beam_128.dat.ref](https://raw.githubusercontent.com/Dhondtguido/CalculiX/9e4fc4a856259ebfae0d7a2659c2c4a8030fe542/test/lin_stat_cooks_beam_128.dat.ref)
- [仓库 LICENSE](https://raw.githubusercontent.com/Dhondtguido/CalculiX/9e4fc4a856259ebfae0d7a2659c2c4a8030fe542/LICENSE)：GNU GPL version 2；输入/输出没有独立许可声明，本次只引用参数与来源，不再分发原文件。

四角为 `(0,0),(48,44),(48,60),(0,44)`、z = 0，共 81 节点、128 个 **US3 用户单元**，每节点 6 DOF、单元 3 节点、3 积分点。`USER SECTION` 声明 CONSTANTS=6，实际输入值一项 1.0。该常数对应的 US3 实现语义尚未审阅，不能静默改成 CPS 厚度并宣称复现。E = 1、ν = 0.333333、density = 1；源未声明命名单位。

左边 Set-4 的 9 节点固定 DOF 1–6。右边 Set-6 = `[1,4,5,6,7,12,13,14,15]`，每节点 `CLOAD(dof2)=0.111111`，总力是 **0.999999**。源是等节点力，改为一致边界面力会改变输入。线性静力步 NLGEOM=NO。

QOI 是节点 1 `(48,52,0)` 的 Uy，原始公开输出 `2.231520E+01` = **22.31520**。文件首行 22.3 只是粗略注释。它是固定离散的求解器回归值，不是独立解析值或网格无关真值。已读来源没有指定验收容差。安装版 CCX 对 US3 的支持、单元实现和适配尚未验证，应保留为待接入案例。

## 4. Code_Aster：SSNV104B 两个等半球压合

官方[参考问题](https://codeaster.gitlab.io/doc/docaster/manuals/man_v/v6/v6.04.104/Probl_me_de_r_f_rence.html)、[解析解](https://codeaster.gitlab.io/doc/docaster/manuals/man_v/v6/v6.04.104/Solution_de_r_f_rence.html)、[模型 B](https://codeaster.gitlab.io/doc/docaster/manuals/man_v/v6/v6.04.104/Mod_lisation_B.html)。[几何图 SVG](https://codeaster.gitlab.io/doc/docaster/manuals/man_v/v6/v6.04.104/_images/1000050000001C6C0000136EA235B717267D9113.svg) 中直接写明 `rayon R = 50 mm`，不是按输出反推半径。

源码提交 `7cb48262af47548277f4824ea47f1cc90848f057` 的 [ssnv104b.comm](https://gitlab.com/codeaster/src/-/blob/7cb48262af47548277f4824ea47f1cc90848f057/astest/ssnv104b.comm) 声明 GPL-3.0-or-later；公开文档保留 EDF 版权。网页没有与该源码提交建立同版证明，因此分别记录页面字节哈希和源码固定提交。

两等半球 R = 50 mm、E = 20000 MPa、ν = 0.3，极点接触、无摩擦。上平面 AB/SPHSUP 的 DY = -2 mm，下平面 CD/SPHINF 的 DY = +2 mm，轴 AC 的 DX = 0，总压合 h = 4 mm。模型 B 为轴对称，376 节点、30 TRIA3 + 324 QUAD4；源码 export 引用 `ssnv104b.mmed`，该网格本次未下载。

第一接触变体是 DISCRETE / PENALISATION、NODAL 配对、slave normal、EN = 1e10，载荷分 10 个等增量施加。另有 MAIT_ESCL 配对的惩罚/约束变体，不能混用对应回归数值。

```text
p0 = -E / [π(1-ν²)] · sqrt(2h/R) = -2798.3286697476105 MPa
a  = sqrt(Rh/2) = 10 mm
p(x) = p0 sqrt(1-(x/a)²), 0≤x≤a
```

文档印刷 p0 = -2798.3 MPa。Hertz 要求 a/R≪1；本例 a/R=0.2，来源明确称为近似解，不能冒称精确有限半球解。源第一变体的回归值为 **-2971.29462582**，实际字段是 `SIGM_ELNO/SIYY`、节点 N291、单元 M31，是积分点外推后的单元节点应力，不能直接当 CCX 原生 contact pressure。

固定源码明确给出这项 SIYY 对 -2798.3 的**相对容差 0.07（7%）**；只适用于该来源的该模型/该 QOI。模型 B 网页表格把压力单位印作 N，而参考问题的 E、解析式量纲及源码 SIYY 都指向 MPa；这里按应力量纲登记并保留此来源矛盾。文档解释误差受高斯点至节点外推与粗网格影响。

本轮仅闭合解析式与来源条件，不声称 Code_Aster FE 已本地复算，更不把源 7% 自动移植成 CCX 接触验收门。

## 5. CalculiX：beam8f 矩形悬臂模态梁

同一官方固定提交的 [beam8f.inp](https://raw.githubusercontent.com/Dhondtguido/CalculiX/9e4fc4a856259ebfae0d7a2659c2c4a8030fe542/test/beam8f.inp) 与 [beam8f.dat.ref](https://raw.githubusercontent.com/Dhondtguido/CalculiX/9e4fc4a856259ebfae0d7a2659c2c4a8030fe542/test/beam8f.dat.ref)，许可边界同 Cook。

全部节点读取后得到 x∈[0,1]、y∈[0,1.5]、z∈[0,8]，425 节点、256 C3D8。E = 210000、ν = 0.3、density = 7.8e-9；z=0 的完整 25 节点固定 DOF1–3。无外力，是 `Kφ=λMφ` 自振问题；`FREQUENCY` 输入 `10,0.01`。源未声明命名单位，可解释为 mm/N/s/tonne，对应 density tonne/mm³、频率 Hz；解释必须跟随该单位链。

公开前十阶 cycles/time 依次为：

```text
13798.13, 19852.05, 81356.76, 88787.12, 109446.1,
163403.6, 211154.3, 266831.4, 267673.8, 379922.6
```

已独立核对整表 `f=ω/(2π)` 与 `λ=ω²` 在源输出取整误差内一致。这些值是源 C3D8 离散回归参考；不是解析梁理论。换网格/单元后必须另行定义比较资格。来源所读文件没有验收容差，模态 adapter 和本地运行未完成。

## 验证与交付边界

`build_source_manifest.py` 只解析本地取得的原文件、计算哈希及少量标量公式，不 import/exec 任何第三方脚本。当前运行 39 项检查通过；读取失败也保留在 `sources.json`：原猜测 GitHub COMET 路径 404、OGS sitemap 404、MOOSE 页面 403、COMET 全长提交查询 TLS 错误。没有把这些请求当成已读来源。

本轮没有替来源填写默认容差；未给出的 `source_acceptance_tolerance=null`，本地 tolerance 也保持 null，交由案例库按具体 QOI、离散和网格收敛证据决定。COMET 公布 FE 值只是已取整比较参考，两个 CCX `.dat.ref` 是软件回归，Hertz 是有适用前提的近似理论，三者的证据类型不可混称 golden。

公开包可放本报告、`sources.json`、两个 COMET 参数契约和本地原创验证脚本。`cache/` 中第三方完整程序、报告与网页只作本地核验，不放入公开包。外部来源哈希不是本地求解结果哈希，实际 solver artifacts 必须另有清单。

## Where This Review May Be Wrong

- COMET 旧教程没有明确命名单位，全长提交查询失败；目前依据完整脚本、页面短提交和内容哈希。若要逐字节追溯仓库，应在正常 TLS 访问恢复后解析该短提交，不应改动已冻结物理参数。
- Cook 的 US3 section 实现尚未读，原 CCX 构建也未验证。故只能作为完整源文件与固定输出的待接入案例；单元语义确认和实际运行之前不能给适配 PASS。
- Code_Aster 文档和固定源码不是已证明的同版来源，且原 MED 网格缺失。解析数值和物理条件已核查，原 FE 回归复现仍需固定原网格及相应求解器版本。
