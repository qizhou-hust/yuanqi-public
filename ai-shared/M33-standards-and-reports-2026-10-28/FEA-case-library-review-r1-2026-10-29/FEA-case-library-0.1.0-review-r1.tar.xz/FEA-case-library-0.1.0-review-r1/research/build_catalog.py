"""Create/check source-only public case contracts; no solver or source cache required."""
from pathlib import Path
import argparse
import hashlib
import json
import math

RESEARCH = Path(__file__).resolve().parent
ROOT = RESEARCH.parent
CATALOG = ROOT / "cases" / "catalog"
VERSION = "1.0"


def encoded(data):
    return (json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True, allow_nan=False).encode("utf-8")).hexdigest()


def build():
    source_path = RESEARCH / "sources.json"
    source_bytes = source_path.read_bytes()
    manifest_hash = hashlib.sha256(source_bytes).hexdigest()
    sources = json.loads(source_bytes)
    by_id = {c["id"]: c for c in sources["cases"]}
    source_ids = {
        "beam": "COMET-CANTILEVER-PLANE-STRESS",
        "sphere": "COMET-HOLLOW-SPHERE-EXTERNAL-PRESSURE",
        "hertz": "ASTER-SSNV104B-HERTZ-SPHERES",
        "cook": "CCX-COOK-US3-128",
        "modal": "CCX-BEAM8F-MODAL",
    }
    if set(by_id) != set(source_ids.values()) or sources["public_case_count"] != 5:
        raise ValueError("Expected exactly five independently identified public physical cases")

    def base(which, case_id, model, analysis):
        src = by_id[source_ids[which]]
        return {
            "schema": "case-library.catalog/1", "id": case_id,
            "physical_case_id": src["id"], "title": src["title"],
            "entry_kind": "public_source_catalog", "model": model, "analysis": analysis,
            "units": src["units"], "geometry": src["geometry"], "material": src["material"],
            "boundary_conditions": src["boundary_conditions"], "loading": src["loads"],
            "source": {
                "manifest": "research/sources.json", "record_id": src["id"],
                "manifest_sha256": manifest_hash, "url": src["source_url"],
                "commit": src["commit"], "license": src["license"],
                "artifacts": [{k: a[k] for k in ("id", "url", "sha256", "bytes")} for a in src["source_artifacts"]],
                "redistributes_original_source": False,
            },
            "source_acceptance_tolerance": src["source_acceptance_tolerance"],
            "local_FE_acceptance_tolerance": None,
            "adapter": {"supported": False, "status": "UNSUPPORTED", "run_eligible": False},
            "local_run": {"status": "NOT_RUN", "solver_executed": False, "raw_artifacts": [], "numerical_acceptance": "NOT_ASSESSED", "engineering_acceptance": "NOT_ASSESSED"},
            "counting": {"unit": "one_physical_public_case", "count_mesh_levels_as_cases": False, "count_solver_or_contact_variants_as_cases": False},
            "limitations": src["limitations"],
        }

    hertz = base("hertz", "PUB-ASTER-SSNV104B", "hertz_spheres", "axisymmetric frictionless elastic contact; source model B")
    hertz["geometry"]["radius_unit"] = "mm"
    hertz["material"]["E_unit"] = "MPa"
    hertz["contact"] = by_id[source_ids["hertz"]]["contact"]
    hertz["source_mesh"] = by_id[source_ids["hertz"]]["source_mesh"]
    hertz["source_expected"] = [
        {"id": "central_pressure_signed", "quantity": "Hertz central normal pressure represented as compressive stress", "value": -2798.3, "unit": "MPa", "sign_convention": "compression negative", "reference_kind": "published_rounded_approximate_analytic", "locator": "SSNV104 reference solution section 2.1 and ssnv104b.comm VALE_REFE", "rounding": {"last_displayed_step": .1, "half_step": .05, "purpose": "printed number reproduction only, not FE tolerance"}},
        {"id": "contact_radius", "quantity": "Hertz contact disk radius", "value": 10., "unit": "mm", "reference_kind": "published_analytic", "locator": "SSNV104 reference solution equation 2.1-2, R=50 mm and h=4 mm"},
        {"id": "source_primary_SIYY", "quantity": "element-node extrapolated normal stress", "value": -2971.29462582, "unit": "MPa", "sign_convention": "compression negative", "reference_kind": "published_solver_regression", "state": "RESU2, load factor 1, increment/order 10", "region": {"node": "N291", "element": "M31"}, "field": "SIGM_ELNO/SIYY", "native_contact_pressure": False, "locator": "ssnv104b.comm first TEST_RESU CHAM_ELEM"},
    ]
    hertz["adapter"].update(required_capability="axisymmetric nonlinear contact input, mesh identity, increment tracking, native pressure versus SIGM_ELNO mapping", reason="No supported native FE adapter for this catalog case; original MED mesh is not packaged.")
    hertz["analytic_verification"] = {"supported": True, "record": "research/reference-checks.json", "check_id": "ASTER-SSNV104B-HERTZ-SCALAR", "scope": "Independent closed-form arithmetic; does not execute FE or approve finite-body contact"}
    hertz["reference_applicability"] = {"hypothesis": "frictionless smooth equal spheres, isotropic small-strain elastic half-space asymptote, a/R much smaller than 1", "a_over_R": .2, "status": "FINITE_RATIO_NOT_SMALL_PATCH_PROOF", "interpretation": "Source treats Hertz as an approximation at this ratio; no precise finite-body or arbitrary gear-contact claim"}

    cook = base("cook", "PUB-CCX-COOK-US3", "cook_membrane_us3", "linear static US3 user-element tapered cantilever")
    cook["section"] = by_id[source_ids["cook"]]["section"]
    cook["source_expected"] = [{"id": "node1_Uy", "quantity": "displacement Uy", "value": 22.31520, "unit": "mm under stated local interpretation", "source_named_unit": None, "reference_kind": "published_solver_regression", "state": "step 1, increment 1, time 1", "region": {"node": 1, "position": [48.,52.,0.]}, "sign_convention": "positive global y", "raw_text": "2.231520E+01", "locator": "lin_stat_cooks_beam_128.dat.ref displacement block, NALL row 1", "continuum_exact_golden": False}]
    cook["adapter"].update(required_capability="US3 user element and USER SECTION constant semantics; 6-DOF nodal constraints; source load/readback", reason="US3 implementation compatibility and USER SECTION semantics are not validated by the current solid/axisymmetric adapters.")
    cook["load_identity"] = {"nodal_force_count": 9, "force_per_node": .111111, "total_Fy": .999999, "prohibited_silent_substitution": "consistent edge traction or a rounded exact total load of 1"}
    cook["analytic_verification"] = {"supported": False, "status": "NO_ANALYTIC_REFERENCE_ADOPTED"}

    modal = base("modal", "PUB-CCX-BEAM8F", "beam8f_modal", "undamped linear free-vibration eigenproblem")
    modal["solver_request"] = by_id[source_ids["modal"]]["solver_request"]
    modal["load_definition"] = by_id[source_ids["modal"]]["load_definition"]
    modal["source_expected"] = [
        {"id": f"mode_{v['mode']}", "quantity": "eigenfrequency", "mode": v["mode"], "value": v["frequency_cycles_per_time"], "unit": "cycles/time; Hz under stated mm-N-s-tonne interpretation", "source_named_unit": None, "eigenvalue": v["eigenvalue"], "eigenvalue_unit": "1/time^2", "omega": v["omega"], "omega_unit": "rad/time", "imaginary_omega": v["imaginary_omega"], "reference_kind": "published_solver_regression", "locator": f"beam8f.dat.ref EIGENVALUE OUTPUT row {v['mode']}", "state": "linear frequency step, exact source C3D8 mesh", "continuum_exact_golden": False}
        for v in by_id[source_ids["modal"]]["qoi"]["references"]
    ]
    modal["adapter"].update(required_capability="FREQUENCY step, consistent mass/density readback, ordered eigenpair extraction and mode identification", reason="Current public-case runner is static; no validated modal extraction or mode-identity adapter is provided.")
    modal["analytic_verification"] = {"supported": False, "status": "NO_ANALYTIC_EIGENFREQUENCY_ADOPTED", "note": "Source omega/frequency/eigenvalue dimensional checks are in sources.json; they are not independent continuum validation."}

    # Route A: literal source p0/a formulas. Route B: effective Hertz moduli/radius,
    # then force and central pressure from the integral pressure distribution.
    E, nu = hertz["material"]["E"], hertz["material"]["nu"]
    R, delta = hertz["geometry"]["radius"], hertz["contact"]["total_approach_h"]
    a_a = math.sqrt(R*delta/2)
    p_a = -E/(math.pi*(1-nu**2))*math.sqrt(2*delta/R)
    E_star = 1/(2*(1-nu**2)/E)
    R_star = 1/(2/R)
    a_b = math.sqrt(R_star*delta)
    force_b = (4/3)*E_star*math.sqrt(R_star)*delta**1.5
    p_b = -3*force_b/(2*math.pi*a_b**2)
    tests = [
        {"name": "contact_radius_published", "actual": a_b, "expected": 10., "absolute_error": abs(a_b-10.), "threshold": 1e-12, "threshold_kind": "local arithmetic equality guard, not source FE tolerance"},
        {"name": "peak_pressure_published_rounding", "actual": p_b, "expected": -2798.3, "absolute_error": abs(p_b+2798.3), "threshold": .05, "threshold_kind": "half of source last printed decimal 0.1 MPa, not FE acceptance"},
        {"name": "independent_Hertz_routes_radius", "actual": a_b, "expected": a_a, "absolute_error": abs(a_b-a_a), "threshold": 1e-12, "threshold_kind": "local floating-point arithmetic guard"},
        {"name": "independent_Hertz_routes_pressure", "actual": p_b, "expected": p_a, "absolute_error": abs(p_b-p_a), "threshold": 1e-9, "threshold_kind": "local floating-point arithmetic guard in MPa"},
    ]
    for t in tests:
        t["passed"] = t["absolute_error"] <= t["threshold"]
    if not all(t["passed"] for t in tests):
        raise ValueError("Hertz independent scalar reference check failed")
    checks = {
        "schema": "case-library.reference-checks/1", "generator_version": VERSION,
        "id": "ASTER-SSNV104B-HERTZ-SCALAR", "physical_case_id": hertz["physical_case_id"],
        "source_manifest_sha256": manifest_hash,
        "inputs": {"R_mm": R, "total_approach_mm": delta, "E_MPa": E, "nu": nu},
        "input_digest_sha256": digest({"R_mm": R, "total_approach_mm": delta, "E_MPa": E, "nu": nu}),
        "method_a": {"description": "Transcribed published analytic formula", "a_mm": a_a, "p0_signed_MPa": p_a},
        "method_b": {"description": "Independently assembled effective-modulus/effective-radius, force law, and pressure-integral route", "E_star_MPa": E_star, "R_star_mm": R_star, "a_mm": a_b, "normal_force_N": force_b, "p0_signed_MPa": p_b},
        "tests": tests, "arithmetic_status": "PASS",
        "applicability": hertz["reference_applicability"],
        "local_FE_status": "NOT_RUN", "FE_solver_executed": False,
        "engineering_acceptance": "NOT_ASSESSED",
        "does_not_prove": ["exact finite-body solution at a/R=0.2", "Code_Aster regression rerun", "CalculiX nonlinear contact acceptance", "source 7 percent tolerance eligibility for native contact pressure"],
        "source_SIYY_tolerance_note": hertz["source_acceptance_tolerance"],
        "repeat_command": "python -B research/build_catalog.py --check",
    }
    files = {
        CATALOG / "aster-ssnv104b-hertz.json": hertz,
        CATALOG / "ccx-cook-us3.json": cook,
        CATALOG / "ccx-beam8f-modal.json": modal,
        RESEARCH / "reference-checks.json": checks,
    }
    index = {
        "schema": "case-library.catalog-index/1", "public_physical_case_count": 5,
        "source_catalog_contract_count": 3,
        "count_rule": "Count unique physical_case_id only. Mesh refinement, thickness diagnostic, pressure-discretization rejection and source contact-algorithm variants do not create new public physical cases.",
        "source_manifest": "research/sources.json", "source_manifest_sha256": manifest_hash,
        "entries": [
            {"physical_case_id": source_ids["beam"], "implementation_id": "PUB-COMET-BEAM", "contract": "cases/public/comet-beam.json", "contract_kind": "runnable_public_benchmark", "results_status": "Read current results ledger; this source index makes no run claim"},
            {"physical_case_id": source_ids["sphere"], "implementation_id": "PUB-COMET-SPHERE", "contract": "cases/public/comet-sphere.json", "contract_kind": "runnable_public_benchmark", "results_status": "Read current results ledger; this source index makes no run claim"},
            {"physical_case_id": source_ids["hertz"], "implementation_id": hertz["id"], "contract": "cases/catalog/aster-ssnv104b-hertz.json", "contract_kind": "source_only_analytic_check_available", "FE_run_status": "NOT_RUN"},
            {"physical_case_id": source_ids["cook"], "implementation_id": cook["id"], "contract": "cases/catalog/ccx-cook-us3.json", "contract_kind": "source_only_adapter_unsupported", "FE_run_status": "NOT_RUN"},
            {"physical_case_id": source_ids["modal"], "implementation_id": modal["id"], "contract": "cases/catalog/ccx-beam8f-modal.json", "contract_kind": "source_only_adapter_unsupported", "FE_run_status": "NOT_RUN"},
        ],
        "variants_policy": {"mesh_levels": "count as runs under a physical case", "cases/diagnostic/beam-t0.1.json": source_ids["beam"], "cases/diagnostic/beam-t0.01.json": source_ids["beam"], "cases/diagnostic/sphere-coarse-rejected.json": source_ids["sphere"], "Code_Aster pairing or penalty variants": source_ids["hertz"]},
    }
    if len({r["physical_case_id"] for r in index["entries"]}) != 5:
        raise ValueError("Public case/variant counting error")
    for contract in (hertz, cook, modal):
        if contract["adapter"]["supported"] or contract["adapter"]["run_eligible"] or contract["local_run"]["solver_executed"]:
            raise ValueError("Source-only entry promoted to solver result")
        if not contract["source_expected"] or not contract["source"]["artifacts"]:
            raise ValueError("Missing source expectation/provenance")
    files[CATALOG / "index.json"] = index
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="Validate formulas/contracts and compare against saved artifacts without writes")
    args = parser.parse_args()
    outputs = build()
    for path, data in outputs.items():
        if args.check:
            if not path.exists() or json.loads(path.read_text(encoding="utf-8")) != data:
                raise ValueError("Missing or stale catalog artifact: " + str(path))
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(encoded(data))
    print(json.dumps({"status": "PASS", "mode": "check" if args.check else "write", "public_physical_cases": 5, "new_source_catalog_contracts": 3, "Hertz_scalar_checks": 4, "FE_solver_runs": 0, "artifacts_verified": len(outputs)}))


if __name__ == "__main__":
    main()
