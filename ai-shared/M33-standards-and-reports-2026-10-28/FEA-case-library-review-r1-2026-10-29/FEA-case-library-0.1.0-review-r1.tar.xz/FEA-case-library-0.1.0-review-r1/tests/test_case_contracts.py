import copy
import tempfile
import unittest
from pathlib import Path
from caselab.common import validate_case, sha
from caselab.native import generate, preflight, parse_deck
from caselab.results import read_nodal
from caselab.runner import runtime_check

def fixture():
    return {'id':'synthetic_beam','title':'synthetic contract fixture, not public benchmark','model':'cantilever_body_force','units':'N-mm-MPa',
        'geometry':{'length_mm':10.,'height_mm':1.,'width_mm':1.},'material':{'E_MPa':1000.,'nu':.3},
        'loading':{'force_density_N_per_mm3':.001},'reference':{'quantity':'tip_y','value':.015,'relative_tolerance':.05,
        'definition':'tip cross-section mean','tolerance_reason':'fixture'},'source':{'url':'https://example.invalid/fixture',
        'locator':'synthetic','reference_type':'synthetic'},'mesh_levels':[[4,2,2],[8,4,4],[16,8,8]]}

class ContractTests(unittest.TestCase):
    def test_missing_reference_blocked(self):
        c=fixture();del c['reference']
        with self.assertRaises(ValueError):validate_case(c)
    def test_empty_mesh_roster_blocked(self):
        c=fixture();c['mesh_levels']=[]
        with self.assertRaises(ValueError):validate_case(c)
    def test_native_positive_and_mutations(self):
        c=fixture();deck=generate(c,0);r=preflight(deck,c,0);self.assertTrue(r['ready'],r)
        for changed in [deck.replace('*STATIC','*DYNAMIC'),deck.replace('1000,0.3','1000,0.49'),
                        deck.replace('LEFT,1,2,0','LEFT,1,2,1')]:
            with self.subTest():
                self.assertNotEqual(changed,deck)
                self.assertFalse(preflight(changed,c,0)['ready'])
    def test_duplicate_node_rejected(self):
        c=fixture();deck=generate(c,0);text=deck.replace('*NODE\n','*NODE\n1,0,0,0\n')
        self.assertFalse(preflight(text,c,0)['ready'])

    def test_self_equilibrated_extra_load_is_not_uniform_body_force(self):
        c=fixture();deck=generate(c,0);d=parse_deck(deck)
        ns=[n for n,p in d['nodes'].items() if p[1]==0 and p[0]>0][:2]
        changed=deck.replace('*CLOAD\n',f'*CLOAD\n{ns[0]},1,1\n{ns[1]},1,-1\n')
        r=preflight(changed,c,0)
        self.assertTrue(r['checks']['force_moment'])
        self.assertFalse(r['checks']['load_distribution'])
        self.assertFalse(r['ready'])

    def test_redistributed_existing_dofs_rejected_even_with_same_resultants(self):
        c=fixture();deck=generate(c,0);d=parse_deck(deck)
        ns=[n for n,p in d['nodes'].items() if p[0]==0][:2]
        lines=deck.splitlines();in_load=False
        for i,line in enumerate(lines):
            if line.startswith('*'):in_load=line=='*CLOAD';continue
            if in_load:
                n,di,v=line.split(',')
                if int(n) in ns:
                    lines[i]=f'{n},{di},{float(v)+(1 if int(n)==ns[0] else -1):.14g}'
        r=preflight('\n'.join(lines)+'\n',c,0)
        self.assertTrue(r['checks']['force_moment'])
        self.assertFalse(r['checks']['load_distribution'])
        self.assertFalse(r['ready'])

    def test_case_mesh_level_binds_load_roster(self):
        c=fixture()
        self.assertFalse(preflight(generate(c,0),c,1)['checks']['load_distribution'])

    def test_sphere_load_roster_positive_and_component_change(self):
        c=fixture();c['model']='hollow_sphere_external_pressure'
        c['geometry']={'inner_radius_mm':9.,'outer_radius_mm':11.}
        c['loading']={'external_pressure_MPa':10.}
        c['mesh_levels']=[[4,16],[8,32],[16,64]]
        deck=generate(c,0);self.assertTrue(preflight(deck,c,0)['ready'])
        d=parse_deck(deck);n,di,v=d['loads'][0]
        changed=deck.replace(f'{n},{di},{v:.14g}\n',f'{n},{di},{2*v:.14g}\n')
        self.assertNotEqual(deck,changed)
        self.assertFalse(preflight(changed,c,0)['checks']['load_distribution'])

    def test_bc_and_load_order_must_match_supported_step(self):
        c=fixture();deck=generate(c,0)
        bc='*BOUNDARY\nLEFT,1,2,0\n'
        after=deck.replace(bc,'')+bc
        inside=deck.replace(bc,'').replace('*CLOAD\n',bc+'*CLOAD\n')
        before=deck.replace('*STEP\n*STATIC\n1,1\n','').replace('*NODE PRINT,NSET=ALL','*STEP\n*STATIC\n1,1\n*NODE PRINT,NSET=ALL')
        for text in [after,inside,before]:
            with self.subTest(text=text[-60:]):
                r=preflight(text,c,0)
                self.assertFalse(r['checks']['step_order'])
                self.assertFalse(r['ready'])
    def test_raw_field_missing_duplicate_nonfinite_wrong_time(self):
        good='displacements (vx,vy,vz) for set ALL and time  0.1000000E+01\n\n1 0 0 0\n2 1 2 3\n'
        self.assertEqual(len(read_nodal(good,'displacements','ALL',{1,2},1.)),2)
        for bad in [good.replace('2 1 2 3',''),good+'2 1 2 3\n',good.replace('2 1 2 3','2 nan 2 3'),good.replace('0.1000000E+01','0.5000000E+00')]:
            with self.subTest(),self.assertRaises(ValueError):read_nodal(bad,'displacements','ALL',{1,2},1.)

    def test_duplicate_final_blocks_rejected_including_conflicts(self):
        good='displacements (vx,vy,vz) for set ALL and time 1\n1 0 0 0\n'
        for text in [good+good,good+good.replace('1 0 0 0','1 0 99 0')]:
            with self.subTest(),self.assertRaisesRegex(ValueError,'duplicate final field block'):
                read_nodal(text,'displacements','ALL',{1},1.)
        earlier=good.replace('time 1','time 0.5')
        self.assertEqual(read_nodal(earlier+good,'displacements','ALL',{1},1.),{1:[0.,0.,0.]})

    def test_runtime_must_bind_actual_executable_and_digest(self):
        with tempfile.TemporaryDirectory() as tmp:
            exe=Path(tmp)/'solver';exe.write_bytes(b'synthetic non-executable fixture')
            other=Path(tmp)/'other';other.write_bytes(b'unrelated file')
            c={'adapter':'wsl_calculix','executable':str(exe),
               'identity_files':[{'path':str(exe),'sha256':sha(exe)}]}
            self.assertTrue(runtime_check(c))
            replacement=copy.deepcopy(c);replacement['executable']=str(other)
            with self.assertRaisesRegex(ValueError,'Actual executable'):
                runtime_check(replacement)
            c['identity_files'][0]['sha256']=sha(other)
            with self.assertRaisesRegex(ValueError,'identity changed'):runtime_check(c)

if __name__=='__main__':unittest.main()
