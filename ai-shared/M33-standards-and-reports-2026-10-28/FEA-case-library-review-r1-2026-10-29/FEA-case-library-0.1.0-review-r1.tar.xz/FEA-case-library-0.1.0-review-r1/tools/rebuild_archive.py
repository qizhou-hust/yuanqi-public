"""Rebuild the frozen archive without local machine paths or a solver."""
import argparse
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path(__file__).resolve().parent))
from replay import verify_manifest, ROOT

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();dest=a.output.resolve()
    if dest.exists() or dest.is_relative_to(ROOT):raise ValueError('Choose a new output path outside the package')
    verify_manifest(ROOT);dest.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
        for path in sorted(p for p in ROOT.rglob('*') if p.is_file()):
            info=zipfile.ZipInfo(ROOT.name+'/'+path.relative_to(ROOT).as_posix(),(2026,10,29,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            z.writestr(info,path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    print(dest)

if __name__=='__main__':main()
