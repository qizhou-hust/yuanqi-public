"""One-command offline review. A PASS confirms evidence replay, not engineering approval."""
import argparse
import importlib.util
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from caselab.common import read, write, sha
from caselab.studies import need, replay_public

ROOT=Path(__file__).resolve().parents[1]

def verify_manifest(root):
    m=read(root/'MANIFEST.json'); rows=m['files']; paths=[r['path'] for r in rows]
    need(bool(rows) and len(set(paths))==len(paths), 'Manifest must be nonempty/unique')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
    need(actual==set(paths), 'Exact file set differs: '+str(sorted(actual.symmetric_difference(paths))[:20]))
    for r in rows:
        p=(root/r['path']).resolve()
        need(p.is_relative_to(root) and p.is_file(), 'Invalid manifest path')
        need(p.stat().st_size==r['bytes'] and sha(p)==r['sha256'], 'Content identity: '+r['path'])
    need(m['file_count']==len(rows), 'Manifest count')
    return {'files':len(rows),'bytes':sum(r['bytes'] for r in rows),'passed':True}

def invoke(args, output, name):
    result=subprocess.run([sys.executable,'-B','-X','utf8',*args],cwd=ROOT,capture_output=True,text=True,encoding='utf8')
    (output/(name+'.log')).write_text(result.stdout+result.stderr,encoding='utf8')
    need(result.returncode==0, name+' failed; see '+str(output/(name+'.log')))
    return {'passed':True,'returncode':result.returncode,'log':name+'.log'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    out=a.output.resolve();need(not out.is_relative_to(ROOT),'Output must be outside the frozen package')
    out.mkdir(parents=True,exist_ok=False)
    report={'schema':'case-library.audit/1','solver_executed':False,'engineering_accepted':False,'passed':False}
    try:
        report['integrity']=verify_manifest(ROOT)
        report['tests']=invoke(['-m','unittest','discover','-s','tests','-v'],out,'unit-tests')
        report['sources']=invoke(['research/build_catalog.py','--check'],out,'public-sources')
        pub=replay_public(ROOT);write(out/'public-replay.json',pub)
        report['public']={'physical_FE_cases':pub['new_physical_FE_cases'],'new_actual_jobs_replayed':pub['actual_solver_jobs'],'passed':True}
        spec=importlib.util.spec_from_file_location('legacy_verifier',ROOT/'legacy/verify.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        old=mod.verify(ROOT/'legacy');write(out/'legacy-verification.json',old);need(old['passed'], 'Legacy coverage: '+str(old['errors']))
        report['legacy']=old
        catalog=read(ROOT/'CATALOG.json');index=read(ROOT/'cases/catalog/index.json');legacy=read(ROOT/'legacy/index.json')
        expected={x['physical_case_id'] for x in index['entries']}|set(legacy['case_ids'])
        need(len(expected)==25 and len(catalog['entries'])==25 and {x['id'] for x in catalog['entries']}==expected,'Exact 25-case roster')
        for row in catalog['entries']:need((ROOT/row['contract']).is_file(),'Catalog contract missing: '+row['id'])
        report['catalog']={'physical_cases':25,'old_cases':20,'new_public_cases':5,'passed':True}
        report['passed']=True
    except Exception as exc:
        report['error']=type(exc).__name__+': '+str(exc)
    write(out/'audit-report.json',report)
    print(json.dumps({'passed':report['passed'],'report':str(out/'audit-report.json'),'solver_executed':False,'engineering_accepted':False},ensure_ascii=False))
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
