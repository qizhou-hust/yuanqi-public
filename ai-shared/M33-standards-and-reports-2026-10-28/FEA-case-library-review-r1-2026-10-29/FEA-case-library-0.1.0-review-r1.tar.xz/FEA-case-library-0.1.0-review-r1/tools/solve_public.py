import argparse
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from caselab.common import read,write
from caselab.runner import solve

def main():
    p=argparse.ArgumentParser();p.add_argument('--case',required=True);p.add_argument('--runtime',required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--levels',default='0,1,2')
    a=p.parse_args();case=read(a.case);config=read(a.runtime)
    a.output.mkdir(parents=True,exist_ok=False)
    records=[]
    for level in map(int,a.levels.split(',')):records.append(solve(case,level,a.output/f'level-{level}',config))
    write(a.output/'study.json',{'case_id':case['id'],'new_actual_solver_runs':True,'records':records,'engineering_accepted':False})
    return 0 if all(r['complete'] for r in records) else 2

if __name__=='__main__':raise SystemExit(main())
