# 制包验收清单（范围冻结）

本轮仅验证完整可移植的审查交付，不改算法、原生输入、物理参考或容差。下列清单约束提交方制包流程；外部审查者可以提出额外发现，不受此清单限制。

| ID | 条件 | 检查方法 |
|---|---|---|
| C1 | 文件清单非空且完整，无临时目录/重复旧包/未列入文件，所有 SHA256 一致 | `audit.py verify` 的 integrity |
| C2 | 实现等于发布 v0.1.0；15 个原生依赖锁一致；wheel 源码相同 | `audit.py verify` 的 origin_and_wheel；PACKAGE-ORIGIN |
| C3 | 清单检查对改动、增添、删除、空清单均能失败 | `audit.py verify` 的 gate_negative_tests |
| C4 | 完整 23 项测试，不允许漏项或跳过后误报通过 | `audit.py core` 的 exact roster |
| C5 | 三个原生案例、四个变异、三项平衡检查完整；ph10 保留 FAIL/UNKNOWN | `audit.py full` 的 exact replay roster |
| C6 | 重放后所有受审文件保持原字节，输出在包外 | `audit.py full` 的 after_integrity |
| C7 | 从最终 ZIP 解压到不同路径、使用独立环境和包内依赖完成 full | 交付方外部侧车验证报告；包内 evidence 为制包时运行证据 |
| C8 | ZIP CRC、每项文件 SHA、ZIP SHA正确，排除文献下载缓存/解释器缓存 | MANIFEST 与 ZIP 校验侧车 |

源码层结构固定为 contracts / theory / pipeline / native adapter / runner / review；公开 CLI 的 precalculate / prepare / review / run 不变。新增 `audit.py` 和 `qa/` 仅作为打包审查工具。

不在本轮制包中完成的工程能力，见 REVIEW-BRIEF 和 docs/ROADMAP。完整包的含义是足以重放列出的检查及审查相关源码/原始证据，不意味着已交付完整商业 FEA 系统。
