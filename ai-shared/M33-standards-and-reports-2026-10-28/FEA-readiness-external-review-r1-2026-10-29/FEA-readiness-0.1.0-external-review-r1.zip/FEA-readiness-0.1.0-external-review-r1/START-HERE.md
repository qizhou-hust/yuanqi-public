# FEA readiness v0.1.0 外部独立审查包 · r1

这是可独立重放的完整审查材料。被审查的实现来自 commit `492ef02a4f1038f9d6ba2f042eab0c27681ac2aa`，业务源码、测试和旧适配器均保留原始字节。本轮仅补充审查入口、运行依赖、原生样本和证据组织。包内的自测通过记录属于提交方证据，不能代替外部独立审查结论。

## 建议先读

1. `REVIEW-BRIEF.md`：审查对象、用户要求、建议核查问题和明确边界。
2. `docs/ARCHITECTURE.md`、`docs/ROADMAP.md`：现有架构、能力范围与后续项。
3. `implementation/fea_readiness/`：实际实现；`implementation/tests/`：23 项测试。
4. `native-assets/`：M37 原始/修复输入、锁定依赖和历史真实求解结果。
5. `evidence/`：本次制包过程重新执行的结果与环境。历史内部审阅另见 `docs/THEORY-AND-DIAGNOSTIC-REVIEW.md`，其结论不应约束外部审查者。

## 仅检查包完整性（标准库，无网络）

从解压目录执行，`--output` 必须是包目录以外尚不存在的新目录：

```text
python -B -X utf8 audit.py verify --output ../audit-integrity
```

`core` 模式再执行 23 项标准库测试；`full` 模式再重放 M37 的 3 个原生案例、4 个错误变异和 ph10 结果审查。所有模式都不会调用真实 FEA 求解器，也不会使用鼠标。

## 完整离线重放

需要已有的 **CPython 3.12、64 位 x86**。包内提供 NumPy 2.2.6、Shapely 2.0.6 的 Windows amd64 与 Linux manylinux2014 x86_64 wheel；Python 解释器不随包提供。其他 Python/操作系统需自行安装相应平台依赖，不应将未运行记作通过。

Windows PowerShell（位于解压目录）：

```powershell
py -3.12 -m venv ..\fea-review-env
..\fea-review-env\Scripts\python.exe -m pip install --no-index --find-links wheels\win-cp312 -r requirements-m37.txt
..\fea-review-env\Scripts\python.exe -B -X utf8 audit.py full --output ..\audit-full
```

Linux（位于解压目录）：

```sh
python3.12 -m venv ../fea-review-env
../fea-review-env/bin/python -m pip install --no-index --find-links wheels/linux-cp312 -r requirements-m37.txt
../fea-review-env/bin/python -B -X utf8 audit.py full --output ../audit-full
```

依赖安装不需要联网。`implementation` 直接从源码加载，不要求安装本项目 wheel；可安装版本另放在 `wheels/fea_readiness-0.1.0-py3-none-any.whl`，入口会核对 wheel 与源码字节一致。Linux 若缺少系统 venv/ensurepip 组件，需先准备 Python 环境。

提交方本轮实跑环境为 Windows 11、CPython 3.12.4 的独立虚拟环境。Linux wheel 已核对 PyPI SHA256，但本轮没有在 Linux CPython 3.12 实跑；不要将其列为已验证平台。

## 运行结果如何理解

退出码 0 仅说明本次打包验证项符合固定预期；退出码 2 表示缺证或失败。完整重放的预期是：原始 ph00 被拒绝、修复 ph00/ph10 获得诊断发算资格、4 项变异被拒绝；ph10 实际承压区网格检查为 FAIL，网格收敛和理论比较仍为 UNKNOWN。它们不能被写成工程验收通过。

输出保存在所指定目录的 `audit-report.json`、`unit-tests.txt`、`native-replay.txt` 和 `m37/`。完整模式不是求解器复算：它读取历史 DAT/STA/LOG/FRD 等，审查其对应输入和抽取逻辑。没有附求解器可执行程序或商业软件许可证。

`MANIFEST.json` 列出全部文件的字节数与 SHA256；清单自身由外部 ZIP SHA256 固定。第三方 wheel 保留原始许可证，来源在 `DEPENDENCIES.json`。文献交付固定 URL、版本/commit、阅读范围与哈希，不附收费标准或文献下载缓存。

`historical-process/` 保存当时实际重跑的脚本和求解器环境身份，仅供追溯阅读；脚本依赖原机器布局，不作为本包运行入口。`audit.py` 会核对历史 null 退出记录、后续真实重跑记录和两份 DAT 的哈希关系。
