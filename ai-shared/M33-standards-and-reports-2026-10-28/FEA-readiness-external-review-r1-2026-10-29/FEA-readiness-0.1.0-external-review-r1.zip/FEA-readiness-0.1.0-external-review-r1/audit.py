"""Portable, offline packaging audit. No FE solver is invoked.

The packaged implementation remains byte-identical to the published v0.1.0.
This wrapper checks archive integrity and an exact replay roster; it does not
replace an external reviewer's engineering judgment or adversarial tests.
"""
import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CASE_EXPECTED={'original_ph00':False,'repaired_ph00':True,'repaired_ph10':True}
MUTATION_EXPECTED={'nonzero_fixed_wheel','wrong_pair_point','wrong_phase','wrong_preload'}
BALANCE_EXPECTED={'balance.wheel_contact_force_residual_rel','balance.wheel_contact_moment_residual_rel',
                  'balance.pinion_contact_vs_input_torque_residual_rel'}

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def write(path,data):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def integrity(root):
    root=Path(root).resolve();manifest=read(root/'MANIFEST.json');entries=manifest['files']
    if not entries:raise ValueError('Manifest cannot be empty')
    names=[x['path'] for x in entries]
    if len(names)!=len(set(names)):raise ValueError('Duplicate manifest path')
    errors=[]
    for item in entries:
        p=(root/item['path']).resolve()
        if not p.is_relative_to(root):raise ValueError('Manifest path leaves bundle')
        if not p.is_file():errors.append('missing: '+item['path']);continue
        if p.stat().st_size!=item['bytes'] or sha(p)!=item['sha256']:errors.append('changed: '+item['path'])
    actual=set()
    for p in root.rglob('*'):
        if p.is_symlink():errors.append('symlink: '+str(p.relative_to(root)))
        if p.is_file():actual.add(p.relative_to(root).as_posix())
    unexpected=actual-set(names)-{'MANIFEST.json'}
    errors.extend('unexpected: '+x for x in sorted(unexpected))
    forbidden={'__pycache__','.git','build','.venv','node_modules'}
    for name in actual:
        if forbidden.intersection(Path(name).parts) or name.endswith(('.pyc','.pyo')):
            errors.append('hygiene: '+name)
    return {'pass':not errors,'files':len(entries),'errors':errors}

def origin_check():
    origin=read(ROOT/'PACKAGE-ORIGIN.json');errors=[]
    for item in origin['sources']:
        if sha(ROOT/item['path'])!=item['source_sha256']:errors.append(item['path'])
    lock=read(ROOT/'implementation/fea_readiness/adapters/m37-assets.json')['files']
    if len(lock)!=15:errors.append('Expected 15 frozen native dependencies')
    for name,value in lock.items():
        if sha(ROOT/'native-assets'/name)!=value:errors.append(name)
    wheel=ROOT/'wheels/fea_readiness-0.1.0-py3-none-any.whl'
    with zipfile.ZipFile(wheel) as z:
        for p in (ROOT/'implementation/fea_readiness').rglob('*'):
            if p.is_file():
                name=p.relative_to(ROOT/'implementation').as_posix()
                if z.read(name)!=p.read_bytes():errors.append('wheel: '+name)
    current=ROOT/'native-assets/preprocessing-work/m37-ph10-ph11-evidence/ph10'
    old=ROOT/'native-assets/m37-results/runs/L3'
    record=read(current/'repeat-record.json');stem='L3_C001_G1_ph10_d12'
    lineage={
        'source_record_sha':sha(old/(stem+'.record.json'))==record['source_record_sha256'],
        'source_exit_code_still_null':read(old/(stem+'.record.json'))['run']['returncode'] is None,
        'repeat_input_sha':sha(current/(stem+'.inp'))==record['input_sha256'],
        'repeat_dat_sha':sha(current/(stem+'.dat'))==record['dat_sha256'],
        'source_dat_sha':sha(old/(stem+'.dat'))==record['source_dat_sha256'],
        'repeat_and_old_dat_identical':sha(old/(stem+'.dat'))==sha(current/(stem+'.dat')),
    }
    errors.extend('lineage: '+name for name,value in lineage.items() if not value)
    return {'pass':not errors,'upstream_commit':origin['upstream_commit'],'source_files':len(origin['sources']),
            'locked_native_files':len(lock),'wheel_sources_identical':not errors,'historical_lineage':lineage,'errors':errors}

def check_replay(output):
    summary=read(output/'replay-summary.json');cases=summary['cases']
    case_map={x['case']:x['actual_ready'] for x in cases}
    mutations=read(output/'mutation-check.json')['rows']
    review=read(output/'ph10.review.json');checks={x['check_id']:x for x in review['checks']}
    balances={k for k in checks if k.startswith('balance.')}
    conditions={
        'exact_three_cases':len(cases)==3 and case_map==CASE_EXPECTED,
        'exact_four_mutations':len(mutations)==4 and {x['mutation'] for x in mutations}==MUTATION_EXPECTED,
        'all_mutations_blocked':len(mutations)==4 and all(x['ready'] is False for x in mutations),
        'exact_balance_roster':balances==BALANCE_EXPECTED,
        'balance_pass':balances==BALANCE_EXPECTED and all(checks[k]['status']=='PASS' for k in BALANCE_EXPECTED),
        'loaded_edge_flagged':checks.get('actual_contact_mesh',{}).get('status')=='FAIL',
        'mesh_remains_unknown':checks.get('mesh_convergence',{}).get('status')=='UNKNOWN',
        'theory_remains_unknown':checks.get('theory_comparison',{}).get('status')=='UNKNOWN',
        'sources_bound':checks.get('result_sources',{}).get('status')=='PASS',
        'historical_run_complete':checks.get('run_completion',{}).get('status')=='PASS',
        'engineering_not_accepted':review['engineering_accepted'] is False,
        'no_solver':summary['solver_invoked'] is False,
    }
    return {'pass':all(conditions.values()),'conditions':conditions}

def gate_self_test():
    # Work on throwaway fixtures, never on the frozen evidence.
    results={}
    with tempfile.TemporaryDirectory(prefix='fea-audit-gate-') as d:
        root=Path(d);p=root/'one.txt';p.write_bytes(b'baseline')
        write(root/'MANIFEST.json',{'files':[{'path':'one.txt','bytes':8,'sha256':sha(p)}]})
        results['valid_fixture']=integrity(root)['pass']
        p.write_bytes(b'modified');results['changed_file_rejected']=not integrity(root)['pass']
        p.write_bytes(b'baseline');extra=root/'extra.txt';extra.write_bytes(b'x')
        results['extra_file_rejected']=not integrity(root)['pass'];extra.unlink()
        p.unlink();results['missing_file_rejected']=not integrity(root)['pass']
        write(root/'MANIFEST.json',{'files':[]})
        try:integrity(root);results['empty_manifest_rejected']=False
        except ValueError:results['empty_manifest_rejected']=True
    return {'pass':all(results.values()),'checks':results}

def run(mode,output):
    report={'schema':'fea-readiness.external-audit/1','started_utc':datetime.now(timezone.utc).isoformat(),
            'mode':mode,'python':sys.version,'platform':platform.platform(),'new_solver_run':False,
            'engineering_accepted':False,'checks':{}}
    report['checks']['C1_integrity']=integrity(ROOT)
    report['checks']['C2_origin_and_wheel']=origin_check()
    report['checks']['C3_gate_negative_tests']=gate_self_test()
    if not all(v['pass'] for v in report['checks'].values()):
        report['pass']=False;write(output/'audit-report.json',report);return report
    if mode in {'core','full'}:
        env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
        command=[sys.executable,'-B','-X','utf8',str(ROOT/'qa/run_unit_tests.py'),'--output',str(output/'unit-tests.json')]
        proc=subprocess.run(command,cwd=ROOT/'implementation',env=env,capture_output=True,text=True,encoding='utf8',timeout=90)
        (output/'unit-tests.txt').write_text(proc.stdout+proc.stderr,encoding='utf8')
        stats=read(output/'unit-tests.json') if (output/'unit-tests.json').exists() else {}
        report['checks']['C4_core_tests']={'pass':proc.returncode==0 and stats.get('pass') is True,'returncode':proc.returncode,'details':stats}
    if mode=='full':
        versions={}
        for name in ['numpy','shapely']:
            try:versions[name]=importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:versions[name]=None
        report['dependency_versions']=versions
        if versions!={'numpy':'2.2.6','shapely':'2.0.6'}:
            report['checks']['C5_native_replay']={'pass':False,'reason':'Install pinned replay dependencies; no fallback to partial pass'}
        else:
            command=[sys.executable,'-B','-X','utf8',str(ROOT/'implementation/tools/replay_m37.py'),
                     '--asset-root',str(ROOT/'native-assets'),'--output',str(output/'m37')]
            t=time.monotonic()
            proc=subprocess.run(command,cwd=ROOT/'implementation',env=env,capture_output=True,text=True,encoding='utf8',timeout=300)
            (output/'native-replay.txt').write_text(proc.stdout+proc.stderr,encoding='utf8')
            replay=check_replay(output/'m37') if proc.returncode==0 else {'pass':False}
            report['checks']['C5_native_replay']={**replay,'returncode':proc.returncode,'wall_s':time.monotonic()-t}
    report['checks']['C6_after_integrity']=integrity(ROOT)
    report['pass']=all(v['pass'] for v in report['checks'].values())
    report['not_run']=[] if mode=='full' else ['Native replay']+(['Core unit tests'] if mode=='verify' else [])
    write(output/'audit-report.json',report)
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['verify','core','full']);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();out=a.output.resolve()
    if out.is_relative_to(ROOT):p.error('Output must be outside the frozen bundle')
    out.mkdir(parents=True,exist_ok=False)
    try:r=run(a.mode,out)
    except Exception as e:
        r={'pass':False,'mode':a.mode,'error':f'{type(e).__name__}: {e}','new_solver_run':False}
        write(out/'audit-report.json',r)
    print(json.dumps({'pass':r['pass'],'report':str(out/'audit-report.json'),'mode':a.mode}))
    return 0 if r['pass'] else 2

if __name__=='__main__':raise SystemExit(main())
