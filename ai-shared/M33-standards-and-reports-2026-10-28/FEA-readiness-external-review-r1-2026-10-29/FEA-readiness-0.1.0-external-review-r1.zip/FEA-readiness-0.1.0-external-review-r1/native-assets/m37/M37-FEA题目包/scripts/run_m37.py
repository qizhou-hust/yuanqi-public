#!/usr/bin/env python3
"""M37 FEA 题目包一键运行：生成网格与 .inp → 调用 CalculiX → 后处理 → 收敛外推 → results/results.json。

  python run_m37.py --ccx <ccx 可执行文件> [--threads 4] [--cases L0,L1,L2,L3]
  python run_m37.py --dry-run           # 只生成网格与 .inp 并自检，不求解（不需要 ccx）
  python run_m37.py --smoke --ccx ...   # 约 1–3 分钟的工具链冒烟测试（L0 + L1 最粗级）

依赖：Python ≥ 3.10、gmsh Python 包（pip install gmsh）。不联网、不下载。
可中断续跑：已求解的作业（存在 <job>.record.json 且 .inp 未变）会跳过；--force 全部重算。
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import platform
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(errors="replace")      # Windows 非 UTF-8 控制台下中文输出不致报错
    except Exception:  # noqa: BLE001
        pass
sys.path.insert(0, str(HERE))

import ccx_io  # noqa: E402
import study   # noqa: E402

PACK = HERE.parent
PACK_VERSION = "M37-FEA-pack 1.0 (2026-10-29)"
CASE_FILES = {"L0": "L0_patch.json", "L1": "L1_hertz.json", "L2": "L2_yfs_matrix.json", "L3": "L3_C001_G1.json"}


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def machine_info():
    info = {"platform": platform.platform(), "machine": platform.machine(), "processor": platform.processor(),
            "cpu_count": os.cpu_count(), "python": sys.version.split()[0], "hostname_sha8":
            hashlib.sha256(platform.node().encode()).hexdigest()[:8]}
    try:
        import gmsh
        gmsh.initialize()
        info["gmsh_version"] = gmsh.option.getString("General.Version")
        gmsh.finalize()
    except Exception as ex:      # noqa: BLE001
        info["gmsh_version"] = f"unavailable: {ex}"
    try:
        if sys.platform.startswith("linux"):
            for ln in Path("/proc/meminfo").read_text().splitlines():
                if ln.startswith("MemTotal"):
                    info["mem_total_kB"] = int(ln.split()[1])
    except Exception:            # noqa: BLE001
        pass
    return info


def run_case(cid, case, exp, wd, exe, opts, coord_state, log):
    specs = study.JOBS[cid](case, exp, wd, coord_state, opts)
    if opts.get("smoke"):
        specs = [s for s in specs if s["tags"].get("level", 0) == 0][: (6 if cid == "L0" else 2)]
    recs = []
    for i, sp in enumerate(specs, 1):
        rec = {"id": sp["id"], "case": cid, "group": sp["group"], "tags": sp["tags"], "warnings": []}
        rfile = wd / f"{sp['id']}.record.json"
        t0 = time.perf_counter()
        try:
            inp, meta = sp["build"]()
        except Exception as ex:      # noqa: BLE001
            rec.update(status="build_failed", error=f"{type(ex).__name__}: {ex}", traceback=traceback.format_exc()[-1500:])
            recs.append(rec); log(f"[{cid}] {i}/{len(specs)} {sp['id']} 建模失败：{ex}")
            continue
        rec.update(build_s=round(time.perf_counter() - t0, 2), h=meta.get("h"), penalty=meta.get("penalty"),
                   pairs_in_contact=meta.get("pairs_in_contact"), element_types=meta.get("element_types"),
                   h_check=meta.get("h_check"),
                   mesh=meta["mesh"], lint_errors=meta["lint_errors"][:20], inp_sha256=ccx_io.sha256(inp))
        if meta["lint_errors"]:
            rec["status"] = "lint_failed"; recs.append(rec)
            log(f"[{cid}] {i}/{len(specs)} {sp['id']} 自检失败：{meta['lint_errors'][:3]}")
            continue
        if exe is None:
            rec["status"] = "dry_run"; recs.append(rec)
            q = meta["mesh"]["quality"]
            log(f"[{cid}] {i}/{len(specs)} {sp['id']}  单元 {meta['mesh']['elements']}  minSJ {q['minSJ']['min']:.3f}"
                f"  gamma_min {q['gamma']['min']:.3f}  （未求解）")
            continue
        if rfile.is_file() and not opts.get("force"):
            old = load(rfile)
            if old.get("inp_sha256") == rec["inp_sha256"] and old.get("status") == "solved":
                recs.append(old); log(f"[{cid}] {i}/{len(specs)} {sp['id']} 已有结果，跳过"); continue
        log(f"[{cid}] {i}/{len(specs)} {sp['id']}  单元 {meta['mesh']['elements']}  求解中 …")
        run = ccx_io.run_job(exe, inp, opts["threads"], opts["timeout"])
        if not run["ok"] and meta.get("coord_requested") and \
                any("COOR" in e.upper() for e in run["errors"] + [run.get("log_tail", "")]):
            # 本 ccx 不支持 *EL PRINT COORD：全局关闭（后续作业建模时即不再请求），重建并重算本作业
            coord_state["coord"] = False
            coord_state["note"] = "ccx 拒绝 *EL PRINT COORD，已关闭；齿根应力退化为积分点最大值"
            log("  ! " + coord_state["note"])
            inp, meta = sp["build"]()
            rec["inp_sha256"] = ccx_io.sha256(inp)
            run = ccx_io.run_job(exe, inp, opts["threads"], opts["timeout"])
        rec["run"] = {k: run[k] for k in ("ok", "returncode", "timeout", "wall_s", "finished_marker", "errors",
                                          "warnings_count", "warnings_head")}
        rec["solve_s"] = run["wall_s"]
        rec["sta"] = ccx_io.parse_sta(inp.with_suffix(".sta"))
        if not run["ok"]:
            rec["status"] = "solver_failed"; rec["log_tail"] = run["log_tail"]
            log(f"  ! 求解失败：{(run['errors'] or [run['log_tail'][-300:]])[:2]}")
        else:
            try:
                blocks = ccx_io.parse_dat(inp.with_suffix(".dat"))
                frd = inp.with_suffix(".frd")
                ex, warn = (sp["post"](meta, blocks, frd) if cid == "L1" else sp["post"](meta, blocks))
                rec.update(status="solved", extracted=ex)
                rec["warnings"] += warn
                rec["dat_sha256"] = ccx_io.sha256(inp.with_suffix(".dat"))
                log("    " + ", ".join(f"{k}={v:.6g}" for k, v in ex.items() if isinstance(v, float))[:300])
            except Exception as ex:  # noqa: BLE001
                rec.update(status="post_failed", error=f"{type(ex).__name__}: {ex}", traceback=traceback.format_exc()[-1500:])
                log(f"  ! 后处理失败：{ex}")
        rfile.write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
        recs.append(rec)
    return recs


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ccx", help="CalculiX 可执行文件（或设置环境变量 M37_CCX）")
    ap.add_argument("--threads", type=int, default=int(os.environ.get("M37_THREADS", "1")))
    ap.add_argument("--cases", default="L0,L1,L2,L3")
    ap.add_argument("--l2-points", default="", help="只跑 L2 的部分点，如 P01,P03")
    ap.add_argument("--no-mortar", action="store_true", help="跳过 MORTAR 实验变体")
    ap.add_argument("--dry-run", action="store_true", help="只生成网格与 .inp 并自检，不求解")
    ap.add_argument("--smoke", action="store_true", help="冒烟测试：L0 + L1 最粗级")
    ap.add_argument("--force", action="store_true", help="忽略已有结果，全部重算")
    ap.add_argument("--timeout", type=int, default=3600, help="单个作业超时（秒）")
    ap.add_argument("--out", default=str(PACK / "results"), help="结果目录（默认 results/）")
    a = ap.parse_args(argv)
    out = Path(a.out).resolve()
    runs = out / "runs"
    runs.mkdir(parents=True, exist_ok=True)
    logf = open(out / "run.log", "a", encoding="utf-8")

    def log(s):
        line = f"{dt.datetime.now():%H:%M:%S} {s}"
        print(line, flush=True)
        logf.write(line + "\n"); logf.flush()

    cases = [c.strip() for c in a.cases.split(",") if c.strip()]
    if a.smoke:
        cases = [c for c in cases if c in ("L0", "L1")] or ["L0", "L1"]
    exe, solver = None, {"status": "not_run (dry-run)"}
    if not a.dry_run:
        exe = ccx_io.find_ccx(a.ccx)
        vout, ver = ccx_io.ccx_version(exe, a.threads)
        solver = {"path": str(exe), "version_output": vout[-500:], "version": ver, "sha256": ccx_io.sha256(exe),
                  "threads": a.threads}
        log(f"CalculiX：{exe}  版本 {ver}")
        if ver is None or not ("2.21" <= ver <= "2.23"):
            log(f"  ! 版本 {ver} 不在 2.21–2.23 范围内；继续运行，结果中会记录警告")
    opts = {"threads": a.threads, "timeout": a.timeout, "mortar": not a.no_mortar, "force": a.force, "smoke": a.smoke,
            "l2_points": [p for p in a.l2_points.split(",") if p]}
    coord_state = {"coord": True, "note": None}
    t_all = time.perf_counter()
    all_recs, summaries, warnings = [], [], []
    if solver.get("version") and not ("2.21" <= solver["version"] <= "2.23"):
        warnings.append(f"ccx 版本 {solver['version']} 不在要求的 2.21–2.23")
    for cid in cases:
        case = load(PACK / "cases" / CASE_FILES[cid])
        exp = load(PACK / "expected" / CASE_FILES[cid])
        wd = runs / cid
        wd.mkdir(parents=True, exist_ok=True)
        log(f"===== {cid}：{case.get('title', '')}")
        t0 = time.perf_counter()
        recs = run_case(cid, case, exp, wd, exe, opts, coord_state, log)
        all_recs += recs
        if exe is not None:
            try:
                s = study.SUMMARY[cid](case, exp, recs)
            except Exception as ex:  # noqa: BLE001
                s = {"case_id": cid, "status": "summary_failed", "error": f"{type(ex).__name__}: {ex}",
                     "traceback": traceback.format_exc()[-1500:]}
            s["wall_s"] = round(time.perf_counter() - t0, 1)
            summaries.append(s)
            la = s.get("local_assessment", {})
            log(f"----- {cid} 本地判定：{'通过' if la.get('pass') else '未通过/不完整'}")
    if coord_state["note"]:
        warnings.append(coord_state["note"])
    bad = [r["id"] for r in all_recs if r.get("status") not in ("solved", "dry_run")]
    if bad:
        warnings.append(f"{len(bad)} 个作业未成功：{bad[:20]}")
    res = {"schema": "m37.fea-results/v1", "pack_version": PACK_VERSION,
           "generated_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "mode": "dry_run" if exe is None else ("smoke" if a.smoke else "full"),
           "machine": machine_info(), "solver": solver, "coord_supported": coord_state["coord"],
           "options": {k: v for k, v in opts.items()}, "total_wall_s": round(time.perf_counter() - t_all, 1),
           "inputs_sha256": {str(p.relative_to(PACK)).replace("\\", "/"): ccx_io.sha256(p) for p in
                             sorted(list((PACK / "cases").glob("*.json")) + list((PACK / "expected").glob("*.json"))
                                    + list((PACK / "scripts").glob("*.py")))},
           "cases": summaries, "jobs": all_recs, "warnings": warnings}
    fn = out / ("results.json" if exe is not None else "dry-run.json")
    fn.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    log(f"写出 {fn}（总耗时 {res['total_wall_s']} s）")
    if exe is not None:
        log("下一步：python scripts/pack_results.py  → 生成回传 zip")
    hard = [b for b in bad if "mortar" not in b]          # MORTAR 是实验变体，失败不算整体失败
    return 0 if not hard else 1


if __name__ == "__main__":
    sys.exit(main())
