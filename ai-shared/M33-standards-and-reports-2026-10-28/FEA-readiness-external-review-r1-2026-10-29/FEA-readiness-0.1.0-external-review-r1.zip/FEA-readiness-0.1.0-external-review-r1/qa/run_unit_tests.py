"""Exact frozen test roster, independent of output formatting and nonempty suites."""
import argparse
import json
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'implementation'))

def ids(suite):
    for test in suite:
        if isinstance(test,unittest.TestSuite):yield from ids(test)
        else:yield test.id()

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    suite=unittest.defaultTestLoader.discover(str(ROOT/'implementation/tests'))
    found=sorted(ids(suite));expected=json.loads((ROOT/'qa/expected-tests.json').read_text())
    roster=found==expected and len(found)==23
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'pass':roster and result.wasSuccessful() and not result.skipped,'roster_match':roster,
            'expected_count':23,'run_count':result.testsRun,'discovered':found,
            'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)}
    a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    return 0 if report['pass'] else 2

if __name__=='__main__':raise SystemExit(main())
