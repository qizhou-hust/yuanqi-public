# M37 L3 周期齿号修复诊断

本包不能替代原始 M37 基线。原基线的失败与未求解项原样保留。

- 仅修复接触齿号跨 ±π 的周期展开：以首个接触齿为锚，按最短周期差展开，再选接触面。未更改几何、材料、载荷、标准参考值或验收阈值。
- 16 相位证据：10 个修复后新增实际求解；6 个原有效相位使用当前会话同一输入 SHA 的实际结果，明确标 reused_identical_input，并附源 record/hash。
- 原 ph00 的输入、完整失败原始记录及终止原因在 original-ph00/；修复 ph00 的完整输入与求解输出在 runs/L3/。
- C 点五个 penalty 结果未改，引用原基线包的原始文件身份；本诊断只替换相位证据做诊断汇总。

| 量 | 本地诊断值（正式门另行独立重算） |
|---|---|
| sigma_H_FE | 605.8997799999995 |
| ratio_sigma_H | 1.0052507853655135 |
| c_prime_FE | 12.295042679075621 |
| ratio_c_prime | 0.7839781589852017 |
| c_gamma_FE_16 | 15.785211156519802 |
| c_gamma_FE_8 | 15.90356996420268 |
| ratio_c_gamma | 0.6854183858151229 |
| phase_change | 0.007498082002785984 |
| max_wheel_torque_rel_err | 0.002956337736619844 |
| max_contact_force_rel_err | 0.0030085081711857054 |

本地原门检查：{'pass': False, 'checks': {'mesh_converged': True, 'penalty_extrapolated': True, 'sigma_H_ratio': True, 'c_prime_ratio': False, 'c_gamma_ratio': False, 'phase_converged': True, 'conservation': False}, 'criteria': {'mesh_last_change': 0.02, 'sigmaH_lo': 0.92, 'sigmaH_hi': 1.08, 'c_lo': 0.8, 'c_hi': 1.2, 'phase_change': 0.03, 'torque_err': 0.001, 'contact_force_err': 0.001}}

刚度与守恒门仍失败。最大合力误差 0.3008508%、扭矩误差 0.2956338%，均来自原有效 ph10（本包精确复用），超过原 0.1% 门；其余相位低于该门。

刚度目标仍用原题要求，保持原门失败。单一载荷无法区分 CM 与低载因子的贡献；无制造误差不代表刚度与载荷无关。stiffness-hypothesis.json 记录未闭合解释，未用它换验收目标，也未新增负载扫描求解。

恢复记录 ph10/ph11 的原始输出完整，但进程退出码无法恢复，明确保留 null。严格 good_job 门要求退出码 0，因此独立严格相位完整性仍失败；16 相位标量的独立算术汇总另列为诊断，不等于 16 个严格合格作业。详见 M37-independent-diagnostic.json。
