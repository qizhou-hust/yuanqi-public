"""Preserve original invalid phases; solve valid originals and all corrected diagnostic phases.
Two independent solver working directories at a time, two requested threads each (total <=4).
"""
from pathlib import Path
import sys,json,math,time,datetime as dt,shutil,concurrent.futures
import numpy as np
BASE=Path(__file__).resolve().parent.parent;PACK=BASE/'m37/M37-FEA题目包';OUT=BASE/'m37-results';DIAG=BASE/'m37-l3-periodic-diagnostic';WORK=BASE/'m37-solver-work'
sys.path.insert(0,str(PACK/'scripts'));import cases as C, study, ccx_io, run_m37 as runner
import periodic_index_fix
for p in [DIAG,WORK]:p.mkdir(exist_ok=True)
CASE_FILES=runner.CASE_FILES
case=json.loads((PACK/'cases/L3_C001_G1.json').read_text(encoding='utf8'));exp=json.loads((PACK/'expected/L3_C001_G1.json').read_text(encoding='utf8'));case['_ref']=study.l3_ref(case,exp)
geom=C.PairGeo(case);specs=study.jobs_L3(case,exp,WORK/'unused',{'coord':True},{'mortar':True})
phase_specs={sp['tags']['phase']:sp for sp in specs if sp['group']=='phase'}
real_mesh=C.mesh_2d;box={}
def capture(*args,**kwargs):box['mesh']=real_mesh(*args,**kwargs);return box['mesh']
C.mesh_2d=capture

def deck_mesh(inp):
    from types import SimpleNamespace
    nodes={};elements={};surfaces={};kw='';name=''
    for line in inp.read_text().splitlines():
        if line.startswith('*'):
            kw=line.split(',')[0].upper()
            if kw=='*SURFACE':name=line.split('NAME=')[1].split(',')[0];surfaces[name]=[]
            continue
        vals=line.split(',')
        if kw=='*NODE':nodes[int(vals[0])]=tuple(map(float,vals[1:3]))
        if kw=='*ELEMENT':elements[int(vals[0])]=list(map(int,vals[1:]))
        if kw=='*SURFACE':surfaces[name].append((int(vals[0]),int(vals[1][1:])))
    tri=((0,1,3),(1,2,4),(2,0,5));edges={}
    for old,new in [('PFL','P_FLANK'),('WFL','W_FLANK')]:
        edges[new]=[(e,side,tuple(elements[e][i] for i in tri[side-1])) for e,side in surfaces[old]]
    return SimpleNamespace(nodes=nodes,edges=edges)

def nearest_surface(mesh,name,P):
    edges=mesh.edges[name]
    cand=sorted(edges,key=lambda r:min(math.dist(mesh.nodes[n],P) for n in r[2]))[:12]
    best=None
    for e,side,row in cand:
        pp=np.array([mesh.nodes[n] for n in row]);A=(pp[0]+pp[1])/2-pp[2];B=(pp[1]-pp[0])/2;D=pp[2]-np.array(P)
        coef=[float(D@B),float(B@B+2*D@A),float(3*A@B),float(2*A@A)]
        roots=np.polynomial.polynomial.polyroots(coef)
        ts=[-1.,1.]+[float(t.real) for t in roots if abs(t.imag)<1e-8 and -1<=t.real<=1]
        for t in ts:
            q=A*t*t+B*t+pp[2];dist=float(np.linalg.norm(q-P))
            if best is None or dist<best['distance_mm']:best={'distance_mm':dist,'point':q.tolist(),'element':e,'side':side}
    return best

def audit(meta,mesh,raw_indices,fixed_indices):
    rr=[]
    for pair in meta['pairs']:
        P=pair['point'];a=nearest_surface(mesh,'P_FLANK',P);b=nearest_surface(mesh,'W_FLANK',P)
        rr.append({'theoretical_point':P,'pinion':a,'wheel':b,'gap_between_nearest_points_mm':math.dist(a['point'],b['point'])})
    valid=all(max(r['pinion']['distance_mm'],r['wheel']['distance_mm'])<.01 for r in rr)
    return {'raw_wheel_indices':raw_indices,'selected_wheel_indices':fixed_indices,'selected_center':round(sum(fixed_indices)/len(fixed_indices)),'pairs':rr,'contact_surface_valid':valid,'distance_audit_tolerance_mm':.01,'note':'Geometric audit tolerance only; no physical input or stress acceptance threshold changed.'}

def skeleton(inp,meta,phase,variant):
    sp=phase_specs[phase]
    return {'id':inp.stem,'case':'L3','group':'phase','tags':sp['tags'],'warnings':[],
      'build_s':meta.pop('_build_s',0),'h':meta['h'],'penalty':meta['penalty'],'pairs_in_contact':meta['pairs_in_contact'],'element_types':meta['element_types'],'h_check':meta.get('h_check'),'mesh':meta['mesh'],'lint_errors':meta['lint_errors'],'inp_sha256':ccx_io.sha256(inp),'variant_scope':variant}

def store(rec,dest):
    dest.mkdir(parents=True,exist_ok=True);(dest/(rec['id']+'.record.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=1),encoding='utf8')

jobs=[];audits=[];orig_hashes={};rawmap={}
for j in range(16):
    s=geom.sA+(j+.5)*geom.pb/16;_,_,pairs=geom.phase(s);rawmap[j]=[r['k2'] for r in pairs]
    stem=phase_specs[j]['id'];work=WORK/('original-'+stem);t=time.perf_counter()
    dest=OUT/'runs/L3';old=dest/(stem+'.inp')
    if old.exists():
        inp=old;meta=json.loads(inp.with_suffix('.meta.json').read_text(encoding='utf8'));mesh=deck_mesh(inp)
    else:
        inp,meta=C.build_L3(case,work,s_ref=s,div=12,alpha=10.0,contact='penalty',tag=stem);meta['_build_s']=round(time.perf_counter()-t,2);mesh=box['mesh'];shutil.copy2(inp,old);shutil.copy2(inp.with_suffix('.meta.json'),dest/inp.with_suffix('.meta.json').name)
    ar=audit(meta,mesh,rawmap[j],rawmap[j]);ar.update(phase=j,scope='original');audits.append(ar);orig_hashes[j]=ccx_io.sha256(inp)
    if j==0:
        rec=json.loads((dest/(stem+'.record.json')).read_text(encoding='utf8'));rec.update(execution_status='terminated_invalid_contact_surface',solver_started=True,contact_surface_audit=ar,termination_evidence='original-ph00-termination.json');store(rec,dest)
    elif not ar['contact_surface_valid']:
        rec=skeleton(inp,meta,j,'original_baseline');rec.update(status='build_failed',execution_status='skipped_invalid_contact_surface',solver_started=False,error='Original periodic wheel tooth indices select the opposite-side contact surface; solver intentionally not started after geometric audit.',contact_surface_audit=ar);store(rec,dest)
    else:jobs.append({'inp':inp,'meta':meta,'rec':skeleton(inp,meta,j,'original_baseline'),'dest':dest,'scope':'original'})
    print('original audit',j,rawmap[j],ar['contact_surface_valid'],flush=True)

old_phase=periodic_index_fix.install(C)
for j in range(16):
    s=geom.sA+(j+.5)*geom.pb/16;_,_,pairs=geom.phase(s);fixed=[r['k2'] for r in pairs]
    stem=phase_specs[j]['id'];work=WORK/('corrected-'+stem);t=time.perf_counter()
    if j>=10:
        assert fixed==rawmap[j],('unchanged single-pair mapping',j)
        work.mkdir(parents=True,exist_ok=True);inp=work/(stem+'.inp');shutil.copy2(OUT/'runs/L3'/inp.name,inp);shutil.copy2((OUT/'runs/L3'/inp.name).with_suffix('.meta.json'),inp.with_suffix('.meta.json'));meta=json.loads(inp.with_suffix('.meta.json').read_text(encoding='utf8'));mesh=deck_mesh(inp)
    elif (work/(stem+'.inp')).exists() and (DIAG/'execution-plan.json').exists():
        plan=json.loads((DIAG/'execution-plan.json').read_text(encoding='utf8'));assert plan['adapter_sha256']==ccx_io.sha256(BASE/'m37/periodic_index_fix.py');assert plan['original_source_sha256']==ccx_io.sha256(PACK/'scripts/cases.py')
        inp=work/(stem+'.inp');meta=json.loads(inp.with_suffix('.meta.json').read_text(encoding='utf8'));mesh=deck_mesh(inp)
    else:
        inp,meta=C.build_L3(case,work,s_ref=s,div=12,alpha=10.0,contact='penalty',tag=stem);meta['_build_s']=round(time.perf_counter()-t,2);mesh=box['mesh']
    ar=audit(meta,mesh,rawmap[j],fixed);ar.update(phase=j,scope='corrected');audits.append(ar)
    assert ar['contact_surface_valid'],ar
    ar['same_input_sha_as_original']=ccx_io.sha256(inp)==orig_hashes[j]
    if j>=10:assert ar['same_input_sha_as_original'],('valid phase changed',j)
    rec=skeleton(inp,meta,j,'periodic_index_diagnostic');rec['contact_surface_audit']=ar
    if j<10:jobs.append({'inp':inp,'meta':meta,'rec':rec,'dest':DIAG/'runs/L3','scope':'corrected'})
    print('corrected audit',j,rawmap[j],fixed,'gapmax',max(r['gap_between_nearest_points_mm'] for r in ar['pairs']),flush=True)
C.PairGeo.phase=old_phase
(OUT/'L3-original-surface-selection-audit.json').write_text(json.dumps([a for a in audits if a['scope']=='original'],indent=2),encoding='utf8')
(DIAG/'L3-before-after-surface-selection.json').write_text(json.dumps(audits,indent=2),encoding='utf8')
shutil.copy2(BASE/'m37/original-ph00-interrupted/termination.json',OUT/'original-ph00-termination.json')
shutil.copy2(BASE/'m37/periodic_index_fix.py',DIAG/'periodic_index_fix.py')
# Persist preparation before the long solve stage.
(DIAG/'execution-plan.json').write_text(json.dumps({'scope':'independent diagnostic; never replaces original baseline','workers':2,'threads_each':2,'original_valid_phases':[j for j in range(10,16)],'corrected_phases':list(range(16)),'corrected_new_solver_phases':list(range(10)),'reused_identical_input_phases':list(range(10,16)),'original_source_sha256':ccx_io.sha256(PACK/'scripts/cases.py'),'adapter_sha256':ccx_io.sha256(BASE/'m37/periodic_index_fix.py'),'jobs':[{'scope':j['scope'],'id':j['rec']['id'],'input':str(j['inp'])} for j in jobs]},indent=2),encoding='utf8')

def solve_job(job):
    inp,meta,rec,dest=job['inp'],job['meta'],job['rec'],job['dest']
    cached=dest/(rec['id']+'.record.json')
    if cached.exists():
        previous=json.loads(cached.read_text(encoding='utf8'))
        if previous.get('status')=='solved' and previous.get('inp_sha256')==ccx_io.sha256(inp):
            print('VERIFIED EXISTING',job['scope'],inp.stem,flush=True);return job['scope'],previous
    rec['solver_started']=True
    isolated=WORK/('solve-'+job['scope']+'-'+inp.stem);isolated.mkdir(exist_ok=True)
    source_inp=inp;inp=isolated/source_inp.name
    if source_inp.resolve()!=inp.resolve():
        shutil.copy2(source_inp,inp);shutil.copy2(source_inp.with_suffix('.meta.json'),inp.with_suffix('.meta.json'))
    print('SOLVE',job['scope'],inp.stem,flush=True)
    run=ccx_io.run_job(BASE/'m37/runtime-ccx/ccx-wsl.cmd',inp,2,3600)
    rec['run']={k:run[k] for k in ('ok','returncode','timeout','wall_s','finished_marker','errors','warnings_count','warnings_head')};rec['run']['threads']=2;rec['solve_s']=run['wall_s'];rec['sta']=ccx_io.parse_sta(inp.with_suffix('.sta'))
    if run['ok']:
        try:
            values,warnings=C.post_L3(meta,ccx_io.parse_dat(inp.with_suffix('.dat')));rec.update(status='solved',execution_status='solved',extracted=values,dat_sha256=ccx_io.sha256(inp.with_suffix('.dat')));rec['warnings']+=warnings
        except Exception as e:rec.update(status='post_failed',execution_status='post_failed',error=repr(e))
    else:rec.update(status='solver_failed',execution_status='solver_failed',log_tail=run['log_tail'])
    dest.mkdir(parents=True,exist_ok=True)
    for f in inp.parent.glob(inp.stem+'*'):
        if f.is_file() and f.resolve()!=(dest/f.name).resolve():shutil.copy2(f,dest/f.name)
    store(rec,dest)
    print('DONE',job['scope'],inp.stem,rec['status'],rec.get('extracted',{}).get('mesh_stiffness_N_per_mm_um'),flush=True)
    return job['scope'],rec

# Interleave original and diagnostic work; isolated cwd prevents solver temporary-file races.
original=[j for j in jobs if j['scope']=='original'];corrected=[j for j in jobs if j['scope']=='corrected'];ordered=[]
for i in range(max(len(original),len(corrected))):
    if i<len(original):ordered.append(original[i])
    if i<len(corrected):ordered.append(corrected[i])
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(solve_job,ordered))

baseline_records=[];summaries=[]
for cid in ['L0','L1','L2','L3']:
    recs=[json.loads(f.read_text(encoding='utf8')) for f in sorted((OUT/'runs'/cid).glob('*.record.json'))]
    for r in recs:
        r.setdefault('solver_started',r.get('status') in ('solved','solver_failed','post_failed'));r.setdefault('execution_status',r['status']);store(r,OUT/'runs'/cid)
    baseline_records+=recs;c=json.loads((PACK/'cases'/CASE_FILES[cid]).read_text(encoding='utf8'));e=json.loads((PACK/'expected'/CASE_FILES[cid]).read_text(encoding='utf8'))
    summaries.append(study.SUMMARY[cid](c,e,recs))
assert len(baseline_records)==82,len(baseline_records)
smoke=json.loads((BASE/'m37/smoke-results/results.json').read_text(encoding='utf8'))
res={**smoke,'pack_version':runner.PACK_VERSION+'; execution-control continuation','generated_utc':dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),'mode':'full','cases':summaries,'jobs':baseline_records,'coord_supported':True,'total_wall_s':(dt.datetime.now(dt.timezone.utc)-dt.datetime.fromisoformat('2026-10-29T22:42:34+00:00')).total_seconds(),'options':{'full_matrix_accounted':True,'initial_threads':4,'continuation_workers':2,'continuation_threads_each':2},'warnings':['Nine original phases were not solved because contact surface selection is geometrically invalid; ph00 was terminated after preserving divergence evidence.','Original local Richardson summaries are advisory; independent ingestion uses the stated signed-order fallback.'],'execution_accounting':{'enumerated':82,'solver_started':sum(r['solver_started'] for r in baseline_records),'skipped_invalid_contact_surface':sum(r['execution_status']=='skipped_invalid_contact_surface' for r in baseline_records),'terminated_invalid_contact_surface':1},'inputs_sha256':{str(p.relative_to(PACK)).replace('\\','/'):ccx_io.sha256(p) for p in sorted(list((PACK/'cases').glob('*.json'))+list((PACK/'expected').glob('*.json'))+list((PACK/'scripts').glob('*.py')))}}
(OUT/'results.json').write_text(json.dumps(res,ensure_ascii=False,indent=1),encoding='utf8')
for j in range(10,16):
    stem=phase_specs[j]['id'];source=OUT/'runs/L3';dest=DIAG/'runs/L3';dest.mkdir(parents=True,exist_ok=True)
    rawfile=source/(stem+'.record.json');rec=json.loads(rawfile.read_text(encoding='utf8'));assert rec['status']=='solved',('cannot reuse unsolved phase',j)
    assert ccx_io.sha256(source/(stem+'.inp'))==ccx_io.sha256(WORK/('corrected-'+stem)/(stem+'.inp'))
    for f in source.glob(stem+'*'):
        if f.is_file() and f.resolve()!=(dest/f.name).resolve():shutil.copy2(f,dest/f.name)
    shutil.copy2(rawfile,dest/(stem+'.source-record.json'))
    rec.update(execution_status='reused_identical_input',solver_started=False,variant_scope='periodic_index_diagnostic',reused_from={'source':'original_baseline','job':stem,'inp_sha256':ccx_io.sha256(source/(stem+'.inp')),'dat_sha256':ccx_io.sha256(source/(stem+'.dat')),'record_sha256':ccx_io.sha256(rawfile),'source_solver_started':True},contact_surface_audit=next(a for a in audits if a['scope']=='corrected' and a['phase']==j))
    store(rec,dest)
phases=[json.loads(f.read_text(encoding='utf8')) for f in sorted((DIAG/'runs/L3').glob('*.record.json'))]

assert len(phases)==16
baseC=[r for r in baseline_records if r['case']=='L3' and r['group']!='phase']
diag={'schema':'m37.l3-phase-diagnostic/v1','scope':'Only periodic wheel-index unwrapping changes; never replaces the original baseline. C-point evidence is unchanged and referenced from the baseline.','source_adapter':'periodic_index_fix.py','phase_jobs':phases,'execution_accounting':{'phases':16,'new_solver_started':10,'reused_identical_input':6},'baseline_C_job_ids':[r['id'] for r in baseC],'local_L3_summary':study.summarize_L3(case,exp,baseC+phases)}
(DIAG/'diagnostic.json').write_text(json.dumps(diag,ensure_ascii=False,indent=1),encoding='utf8')
print('BASELINE AND DIAGNOSTIC MATRIX COMPLETE',res['execution_accounting'],flush=True)
