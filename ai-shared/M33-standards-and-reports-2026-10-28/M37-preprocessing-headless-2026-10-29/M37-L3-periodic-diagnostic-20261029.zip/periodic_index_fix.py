"""Own diagnostic adapter: unwrap periodic wheel indices near the first contact tooth."""
def install(cases_module):
    original = cases_module.PairGeo.phase
    def phase(self, s_ref):
        phi, psi, pairs = original(self, s_ref)
        if pairs:
            anchor = pairs[0]["k2"]
            period = self.g2.z
            for pair in pairs:
                delta = (pair["k2"] - anchor + period / 2) % period - period / 2
                pair["k2"] = anchor + int(round(delta))
            assert max(p["k2"] for p in pairs) - min(p["k2"] for p in pairs) < period / 2
        return phi, psi, pairs
    cases_module.PairGeo.phase = phase
    return original
