"""Independent diagnostic: exact fixed arclength traction patch on the same P02 meshes.
Baseline results and source case files are never modified. Run --solve only after the full baseline.
"""
from pathlib import Path
import sys, json, math, argparse, hashlib
import numpy as np
BASE=Path(__file__).resolve().parent.parent
PACK=BASE/'m37/M37-FEA题目包'
sys.path.insert(0,str(PACK/'scripts'))
import cases as C
import ccx_io
OUT=BASE/'m37-diag-p02'
OUT.mkdir(exist_ok=True)
GAUSS_X,GAUSS_W=np.polynomial.legendre.leggauss(10)

def shp(t):return (.5*t*(t-1),.5*t*(t+1),1-t*t)
def derivative(t):return (t-.5,t+.5,-2*t)
def point(xy,t):
    N=shp(t);return tuple(sum(N[i]*xy[i][j] for i in range(3)) for j in range(2))
def arc_param(xy,t,Rl,rb):
    x,y=point(xy,t);return (x*x+y*y-Rl*Rl)/(2*rb)
def inverse_arc(xy,s,Rl,rb):
    lo,hi=-1.,1.;asc=arc_param(xy,hi,Rl,rb)>arc_param(xy,lo,Rl,rb)
    for _ in range(70):
        mid=(lo+hi)/2;value=arc_param(xy,mid,Rl,rb)
        if (value<s)==asc:lo=mid
        else:hi=mid
    return (lo+hi)/2

def clipped_loads(mesh,meta,rb,w):
    pl=meta['load_point'];Rl=math.hypot(*pl); weights={};pieces=[]
    for e,side,row in mesh.edges['T0_R_INV']:
        xy=[mesh.nodes[n] for n in row]
        if min(math.dist(pt,pl) for pt in xy)>5*w:continue
        sa,sb=arc_param(xy,-1,Rl,rb),arc_param(xy,1,Rl,rb)
        low,high=max(min(sa,sb),-w),min(max(sa,sb),w)
        if high<=low:continue
        ta,tb=sorted([inverse_arc(xy,low,Rl,rb),inverse_arc(xy,high,Rl,rb)])
        acc=[0.,0.,0.]
        for q,weight in zip(GAUSS_X,GAUSS_W):
            t=(ta+tb)/2+(tb-ta)*float(q)/2
            N=shp(t);dN=derivative(t)
            dx=sum(dN[i]*xy[i][0] for i in range(3));dy=sum(dN[i]*xy[i][1] for i in range(3))
            ds=math.hypot(dx,dy)*float(weight)*(tb-ta)/2
            for i in range(3):acc[i]+=N[i]*ds
        for n,v in zip(row,acc):weights[n]=weights.get(n,0.)+v
        pieces.append({'element':e,'side':side,'nodes':row,'xi':[ta,tb],'arc_bounds':[low,high]})
    L=sum(weights.values());assert L>0
    # Constant direction and unchanged resultant Fn; normalize by the integrated geometric patch length.
    loads={(n,d+1):a/L*meta['Fn_per_b']*meta['load_dir'][d] for n,a in weights.items() for d in (0,1)}
    Fx=sum(v for (n,d),v in loads.items() if d==1);Fy=sum(v for (n,d),v in loads.items() if d==2)
    y0=meta['geometry_check']['point_30deg'][1]
    M=sum(mesh.nodes[n][0]*v if d==2 else -(mesh.nodes[n][1]-y0)*v for (n,d),v in loads.items())
    Mnom=pl[0]*Fy-(pl[1]-y0)*Fx
    return loads,{'patch_definition':'fixed analytical involute arclength about HPSTC, +/- 0.05m; quadratic-edge clipping and 10-point Gauss integration',
      'requested_length_mm':2*w,'integrated_length_mm':L,'Fx':Fx,'Fy':Fy,'moment_about_30deg_neutral_point_Nmm':M,'nominal_point_moment_Nmm':Mnom,'moment_ratio':M/Mnom,'pieces':pieces}

def replace_cload(text,loads):
    out=[];skip=False;count=0
    for line in text.splitlines():
        if line.upper().startswith('*CLOAD'):
            out.append(line);out += [f'{n},{d},{v:.15g}' for (n,d),v in sorted(loads.items()) if v]
            skip=True;count+=1;continue
        if line.startswith('*'):skip=False
        if not skip:out.append(line)
    assert count==1
    return '\n'.join(out)+'\n'

ap=argparse.ArgumentParser();ap.add_argument('--solve',action='store_true');ap.add_argument('--threads',type=int,default=4);a=ap.parse_args()
case=json.loads((PACK/'cases/L2_yfs_matrix.json').read_text(encoding='utf8'))
pt=next(x for x in case['points'] if x['id']=='P02')
g=C.l2_gear(pt,case['common']);w=case['model']['load_patch_halfwidth_in_m']*case['common']['m_mm']
real_mesh=C.mesh_2d;box={}
def capture(*args,**kwargs):
    box['mesh']=real_mesh(*args,**kwargs);return box['mesh']
C.mesh_2d=capture
records=[]
for level in range(3):
    original,meta=C.build_L2(case,pt,level,OUT/'recreated-original',True)
    baseline=BASE/'m37-results/runs/L2'/original.name
    assert ccx_io.sha256(original)==ccx_io.sha256(baseline), 'Mesh/input reproduction is not byte-identical'
    loads,identity=clipped_loads(box['mesh'],meta,g.rb,w)
    new=OUT/f'{original.stem}_clipped.inp';new.write_text(replace_cload(original.read_text(),loads),encoding='ascii')
    new.with_suffix('.meta.json').write_text(json.dumps({**meta,'job_id':new.stem,'baseline_job_id':original.stem,'diagnostic_load':identity},ensure_ascii=False,indent=2),encoding='utf8')
    rec={'id':new.stem,'level':level,'baseline_inp_sha256':ccx_io.sha256(baseline),'diagnostic_inp_sha256':ccx_io.sha256(new),'load_identity':identity,'h':meta['h'],'status':'not_solved'}
    if a.solve:
        print('solving',new.stem,flush=True)
        run=ccx_io.run_job(BASE/'m37/runtime-ccx/ccx-wsl.cmd',new,a.threads,3600);run['threads']=a.threads;rec['run']=run;rec['sta']=ccx_io.parse_sta(new.with_suffix('.sta'))
        if run['ok']:
            values,warnings=C.post_L2(meta,ccx_io.parse_dat(new.with_suffix('.dat')))
            rec.update(status='solved',extracted=values,warnings=warnings,dat_sha256=ccx_io.sha256(new.with_suffix('.dat')))
        else:rec['status']='solver_failed'
    new.with_suffix('.record.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf8')
    records.append(rec)
    print(new.stem,identity['integrated_length_mm'],identity['moment_ratio'],rec.get('extracted',{}).get('YFS_FE'),flush=True)
(OUT/'diagnostic.json').write_text(json.dumps({'schema':'m37.load-patch-diagnostic/v1','baseline_unchanged':True,'case':'P02','scope':'diagnostic only; not a replacement baseline or formal acceptance claim','records':records},ensure_ascii=False,indent=2),encoding='utf8')
