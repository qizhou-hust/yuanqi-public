"""Repeat identical phase inputs to capture process status without altering frozen records."""
from pathlib import Path
import sys,json,shutil,concurrent.futures,datetime,hashlib
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent.parent
sys.path.insert(0,str(BASE/'m37/M37-FEA题目包/scripts'))
import cases,ccx_io
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def repeat(phase):
    stem=f'L3_C001_G1_ph{phase:02d}_d12'
    source=BASE/'m37-results/runs/L3'/f'{stem}.inp'
    dest=ROOT/f'ph{phase:02d}';dest.mkdir(exist_ok=True)
    inp=dest/source.name;out=dest/'repeat-record.json'
    if out.exists():
        record=json.loads(out.read_text(encoding='utf8'))
        assert record['input_sha256']==sha(source)==sha(inp)
        assert record['run']['ok'] and record['run']['returncode']==0
        print('REUSING_COMPLETED_REPEAT',phase,flush=True)
        return record
    shutil.copy2(source,inp);shutil.copy2(source.with_suffix('.meta.json'),inp.with_suffix('.meta.json'))
    assert sha(inp)==sha(source)
    original=json.loads(source.with_suffix('.record.json').read_text(encoding='utf8'))
    metadata=json.loads(inp.with_suffix('.meta.json').read_text(encoding='utf8'))
    print('START_IDENTICAL_REPEAT',phase,flush=True)
    run=ccx_io.run_job(BASE/'m37/runtime-ccx/ccx-wsl.cmd',inp,2,3600)
    run['requested_threads']=2
    result={'phase':phase,'scope':'Additional actual process evidence; frozen original null returncode remains unchanged',
            'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':sha(inp),
            'source_record_sha256':sha(source.with_suffix('.record.json')),'source_returncode':original['run']['returncode'],
            'run':run,'sta':ccx_io.parse_sta(inp.with_suffix('.sta'))}
    if run['ok']:
        values,warnings=cases.post_L3(metadata,ccx_io.parse_dat(inp.with_suffix('.dat')))
        result.update(extracted=values,warnings=warnings,dat_sha256=sha(inp.with_suffix('.dat')),
                      source_dat_sha256=sha(source.with_suffix('.dat')),
                      absolute_scalar_differences={k:values[k]-v for k,v in original['extracted'].items() if k in values})
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print('DONE_IDENTICAL_REPEAT',phase,run['returncode'],result.get('extracted'),flush=True)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    rows=list(pool.map(repeat,[10,11]))
(ROOT/'repeat-results.json').write_text(json.dumps({'schema':'m37.identical-repeat-evidence/v1','original_baseline_modified':False,
    'total_requested_threads':4,'records':rows},ensure_ascii=False,indent=2),encoding='utf8')
