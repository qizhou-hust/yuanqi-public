# M37 actual execution notes

## Scope and evidence

The user-supplied case and expected JSON files are byte-identical to the uploaded ZIP. The only solver-runner change is permissive decoding of version-probe diagnostic text; physical input and numeric acceptance gates are unchanged. See input-audit.json for original and current SHA256 identities. The local runtime.patch records the one-line decoder change and remains with local working artifacts; this result package includes no supplied task source code.

The baseline runs use gmsh 4.15.2 on Windows and the supplied CalculiX 2.23 Linux binary under WSL Ubuntu 26.04.1. The command wrapper SHA in results.solver is the launcher identity; the actual solver binary, libraries and gmsh SHA256 identities are in runtime-provenance.json. Total concurrent requested solver threads never exceed four: initially one four-thread process, then at most two two-thread processes. The supplied Spooles factorization reports one CPU.

## Smoke

Actual six-job smoke run: four solved (CPE6 and CPE8 patch, contact penalty patch, coarse Hertz penalty); two experimental MORTAR jobs failed. Separate unmodified smoke outputs are retained locally in m37/smoke-results. Synthetic selfcheck fixtures validate code only and are not physical solver evidence.

## MORTAR failure mechanism

L0c_mortar_h0 has 322 original nodes and no explicit *EQUATION. All 175 reported illegal-MPC slave-node occurrences are above the original maximum node ID; for example node 335 is connected to master node 5/336. Thus the rejected MPCs are introduced by CalculiX's expansion of the 2D element model, not an explicit user equation in the L0c input. The ccx 2.23 spcmpcmortar.f guard at lines 207–214 rejects slave-dependent MPC connections to master nodes. This establishes the observed rejection path for this formulation, not a claim that every alternative 2D MORTAR formulation is impossible. The experiment is preserved as failed; neither contact faces nor physical geometry were removed to suppress errors.

## Acceptance

The final original matrix accounts for 82 entries: 73 actually started the solver, comprising 66 solved, six failed experimental MORTAR jobs and one terminated original phase ph00. Nine original phases ph01-09 were explicitly not started after their contact surfaces were proven invalid. Their schema-compatible status is build_failed, with execution_status=skipped_invalid_contact_surface and solver_started=false. The full mode denotes a complete execution ledger, not 82 successful or attempted solves.

Local summaries are advisory. M37-independent-ingest.json gives the formal independent assessment with mandatory quantity, mesh/phase coverage, raw identity and quality gates. A missing force error is never treated as zero. M37 remains unaccepted; diagnostic packages do not replace the original baseline.

## L2 load identity and extrapolation findings

All 42 baseline L2 jobs solved. The original mid-edge selection of whole loaded quadratic edges changes the effective resultant moment between nominal mesh levels. For P02 the actual/nominal moment at the neutral point of the 30-degree root section is 1.0222237313, 0.9777384478, 1.0213436011 (d8/d12/d18), while the total force is unchanged. The step d12→d18 therefore changes the load moment by about 4.46%; this cannot be described as a pure mesh-convergence experiment. See L2-load-identity-audit.csv for all 42 loads, reconstructed directly from each input deck.

The independent P02 diagnostic preserves the original geometry, mesh, material, constraints, load direction and total Fn. It clips the fixed analytical involute-arclength interval +/-0.05m and integrates quadratic edge shape functions with 10-point Gauss quadrature. Original regenerated input SHA256 identities match the baseline before replacing CLOAD values. Diagnostic patch lengths are 0.19999996–0.19999998 mm; moment ratios are 1.00000002, 0.99999997, 1.00000003. All three diagnostic jobs actually solved, giving YFS_FE=2.6922611668981222, 2.669068446917123, 2.664294592634044 (d8/d12/d18). This removes the load-moment drift without fitting stress outputs. The original baseline remains unchanged; raw diagnostic results and comparison are in the separate P02 diagnostic package.

The original post.richardson function takes the absolute value of a negative observed order during its fixed-point iteration. For monotonically increasing error magnitude, that can misclassify divergence as a positive observed order (notably P08/P14). Independent ingestion instead solves the three-level error model for a positive p in [0.5,5] and falls back to p=2 when no admissible p exists, as required by the supplied specification. Therefore some final extrapolated ratios differ from local_assessment. The baseline local output is preserved, and formal ingestion takes precedence. Neither version's acceptance threshold was relaxed.

Five L2 points fail the baseline ratio gate (P02/P05/P08/P12/P14); the strong positive-profile-shift trend is not explained solely by the few-percent load-patch drift. Residual FE/ISO model/definition discrepancy remains open even if the separate clipping diagnostic improves convergence.

## L3 observed contact-pair check

The five C-point penalty jobs have additional raw-contact evidence: positive contact pressures from the final .dat block are mapped by original element centroid to pinion tooth indices. All active elements map to tooth 0 only, matching the required single pair. This supplements the analytical geometry metadata with the actual pressure support. See L3-contact-pair-audit.json; its pressure cutoff is 1e-6 of the current peak to exclude numerical zero, not an acceptance-threshold relaxation.

## L3 periodic surface selection and controlled interruption

Original phase ph00-09 wheel tooth indices cross the atan2 branch cut ([-35,0] or [-36,-1]). Averaging those raw indices selects the wheel backside. For original ph00 the nominal contact point lies within 0.0004 mm of the pinion flank but approximately 68.93-70.19 mm from the selected wheel flank. The closure step creates zero contact elements, followed by repeated failed force-step iterations and divergent displacement. After preserving the complete raw evidence, only that solver and its sequential driver were stopped. The nine remaining invalid original phase inputs were generated and audited but not started. Original valid ph10-15 were actually solved.

The independent periodic diagnostic unfolds wheel indices by shortest periodic displacement relative to the first active tooth, preserving physical tooth identity modulo 36 and all physical parameters. All 16 corrected surface checks passed. Ten corrected phases ph00-09 were newly solved; six valid original ph10-15 were reused only after exact input SHA verification. Their source records, data SHA and reuse identities are explicit. The separate diagnostic package includes both original ph00 failure evidence and corrected ph00 output.

The corrected phase study has complete results but remains outside the original strict gates: local c_prime_FE/reference=0.7839781589852017 and c_gamma_FE/reference=0.6854183858151229; maximum contact-force and wheel-torque relative errors are 0.0030085081711857054 and 0.002956337736619844, exceeding 0.001. Phase quadrature change is 0.007498082002785984. The geometry defect is closed by evidence, while stiffness and conservation discrepancies remain open. The unchanged low-load and CM sensitivity hypotheses are documented separately without changing targets or adding a load scan.

## Record recovery

A continuation controller attempted to copy a file onto itself after original ph10 and ph11 had completed. Their raw dat, sta and full solver logs remained intact. Those two records were reconstructed from the actual completed outputs without rerunning or modifying measurements. Missing process return codes remain null; elapsed times come from the solver's own log, and record_recovery records the reason and log hash. Subsequent jobs used unique working directories and a same-file copy guard. This operational recovery does not convert a failed physical solve into a successful one.
