"""Portable bounded replays, no author-specific interpreter paths."""
from pathlib import Path
import argparse,sys,subprocess,os,json,datetime,hashlib
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['fast','core','torque','web'],default='fast');ap.add_argument('--python',default=sys.executable);args=ap.parse_args()
out=ROOT/'review_runs'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out.mkdir(parents=True,exist_ok=False)
env=os.environ.copy();env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
if args.mode=='fast':
    m=json.loads((ROOT/'review/FILE_MANIFEST.json').read_text(encoding='utf-8'));bad=[]
    for r in m['files']:
        p=ROOT/r['path']
        if not p.is_file() or hashlib.file_digest(p.open('rb'),'sha256').hexdigest()!=r['sha256']:bad.append(r['path'])
    result={'status':'PASS' if not bad else 'FAIL','checked':len(m['files']),'bad':bad,'note':'Only input integrity; does not certify product correctness.'}
    (out/'REPORT.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result));sys.exit(bool(bad))
commands=[]
if args.mode=='core':
    for profile in ['b8','wb2']:commands.append((ROOT,['tools/core_replay.py','--wheel-profile',profile,'--output',str(out/(profile+'.json'))]))
if args.mode=='torque':commands.append((ROOT,['tools/spoiler_torque_check.py']))
if args.mode=='web':
    w=ROOT/'workspaces/finalists/WORKBENCH_2_0_PRODUCT_R1/WORKBENCH_2_0_PRODUCT_R1'
    commands=[(w,['selfcheck.py']), (w,['scripts/run_final_e2e.py'])]
rows=[]
for idx,(cwd,cmd) in enumerate(commands):
    argv=[args.python,'-X','utf8','-B',*cmd];print('RUN '+str(cmd),flush=True)
    p=subprocess.run(argv,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
    (out/(str(idx)+'.log')).write_bytes(p.stdout)
    rows.append({'argv':argv,'cwd':str(cwd.relative_to(ROOT)),'exit':p.returncode})
report={'status':'PASS' if all(r['exit']==0 for r in rows) else 'FAIL','results':rows,'note':'Bounded replay only; historical probes can document defects despite zero process exit.'}
(out/'REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report));sys.exit(report['status']!='PASS')

