验证顺序说明：
先对22个ZIP做CRC/大小/哈希校验，在全新目录还原7698逻辑文件，做便携完整性检查、扭矩、版本差异、R1自检及缺包负控制。
随后只向00入口包补入本目录验证日志，没有改动PACKAGE_MANIFEST、解包脚本、任何数据对象或源工程内容。
补日志后重新校验00的CRC与逻辑manifest身份，更新外部SHA256SUMS/PACKAGES和最终验证报告。
因此本日志内00的初始哈希属于补入证据之前的身份；最终运输哈希以根目录SHA256SUMS.txt为准。
USER_REQUEST.md为用户需求整理，不是逐字聊天导出；三份原始技术附件和全部materials原件按字节保留。
解包需Python3.11+，推荐Python3.12。历史程序依赖另见requirements-audit.txt。
